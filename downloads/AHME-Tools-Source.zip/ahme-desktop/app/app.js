'use strict';
const catalog = window.AHME_CATALOG;
const $ = selector => document.querySelector(selector);
const make = (tag, className, text) => { const e = document.createElement(tag); if (className) e.className = className; if (text !== undefined) e.textContent = text; return e; };
let selectedCategory = 'home', currentAction = null, running = false, system = { windows: false }, toastTimer;
let favorites;
try { const saved = JSON.parse(localStorage.getItem('ahme-favorites') || '[]'); favorites = new Set(Array.isArray(saved) ? saved.filter(id => catalog.actions.some(a => a.id === id)) : []); } catch { favorites = new Set(); }
const category = id => catalog.categories.find(c => c.id === id);
function toast(text) { $('#toast').textContent = text; $('#toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 5500); }
function saveFavorites() { try { localStorage.setItem('ahme-favorites', JSON.stringify([...favorites])); } catch { toast('تعذر حفظ المفضلة على هذا الجهاز.'); } $('#favorite-count').textContent = favorites.size; }
function info(title, body, resourceLink = false) { $('#info-title').textContent = title; $('#info-body').textContent = body; $('#info-link').hidden = !resourceLink; $('#info-dialog').showModal(); }
function chooseCategory(id) {
  selectedCategory = id; $('#search').value = ''; render();
  window.scrollTo({ top: 0, behavior: 'instant' });
}
function buildNavigation() {
  for (const cat of catalog.categories) {
    const nav = make('button', 'nav-item'); nav.dataset.category = cat.id;
    nav.append(make('span', 'nav-icon', cat.icon), document.createTextNode(cat.title), make('span', 'count', catalog.actions.filter(a => a.category === cat.id).length));
    $('#categories').append(nav);
    const tile = make('button', 'category-tile'); tile.dataset.category = cat.id;
    const head = make('div', 'tile-heading'); head.append(make('span', 'tile-icon', cat.icon), make('span', 'tile-arrow', '←'));
    tile.append(head, make('strong', '', cat.title), make('small', '', `${catalog.actions.filter(a => a.category === cat.id).length} خيارات`));
    $('#category-grid').append(tile);
  }
  document.querySelectorAll('[data-category]').forEach(button => button.addEventListener('click', () => chooseCategory(button.dataset.category)));
}
function card(action) {
  const container = make('article', 'action-card'); container.dataset.action = action.id;
  const head = make('div', 'card-top');
  const favorite = make('button', 'favorite' + (favorites.has(action.id) ? ' selected' : ''), favorites.has(action.id) ? '★' : '☆');
  favorite.setAttribute('aria-label', `مفضلة: ${action.title}`); favorite.setAttribute('aria-pressed', favorites.has(action.id));
  favorite.addEventListener('click', () => { if (favorites.has(action.id)) favorites.delete(action.id); else favorites.add(action.id); saveFavorites(); render(); });
  head.append(make('span', 'card-icon', category(action.category).icon), favorite);
  const foot = make('div', 'card-footer');
  const risk = make('span', 'tag ' + (action.disabled ? 'disabled' : action.risk), action.disabled ? 'غير متاح في الأصل' : action.risk === 'high' ? '△ تعديل حساس' : category(action.category).title);
  const open = make('button', 'open-action', 'التفاصيل والأوامر ←'); open.addEventListener('click', () => showDetail(action.id));
  foot.append(risk, open);
  container.append(head, make('h3', '', action.title), make('p', '', action.description), foot);
  return container;
}
function render() {
  const query = $('#search').value.trim().toLowerCase();
  const home = selectedCategory === 'home' && !query;
  $('#hero').hidden = !home; $('#category-overview').hidden = !home;
  const title = query ? 'نتائج البحث' : selectedCategory === 'home' ? 'نظرة عامة' : selectedCategory === 'all' ? 'جميع الخيارات' : selectedCategory === 'favorites' ? 'المفضلة' : category(selectedCategory).title;
  $('#crumb').textContent = title;
  $('#page-title').textContent = home ? 'كل أدواتك، في مكان واحد.' : title;
  $('#page-description').textContent = home ? 'اختر ما تحتاجه، راجع أثره، ثم طبّقه على جهازك.' : 'راجع تفاصيل الأداة وأوامرها قبل تطبيق أي تغيير.';
  $('#list-title').textContent = home ? 'وصول سريع' : title;
  $('#show-all').hidden = selectedCategory === 'all' && !query;
  document.querySelectorAll('.nav-item').forEach(e => e.classList.toggle('active', e.dataset.category === selectedCategory));
  let actions = catalog.actions;
  if (query) actions = actions.filter(a => [a.title, a.description, a.id, category(a.category).title].join(' ').toLowerCase().includes(query));
  else if (home) actions = ['createRP', 'taskmgr', 'c2', 'fixfiles', 'powerc', 'gmodeon'].map(id => catalog.actions.find(a => a.id === id.toLowerCase()));
  else if (selectedCategory === 'favorites') actions = actions.filter(a => favorites.has(a.id));
  else if (selectedCategory !== 'all') actions = actions.filter(a => a.category === selectedCategory);
  $('#actions').replaceChildren(...actions.map(card));
  $('#empty').hidden = actions.length !== 0; $('#result-count').textContent = actions.length;
  $('#filter-description').textContent = selectedCategory === 'revert' ? 'التراجع يستخدم القيم الأصلية في السكربت. خيارات الطاقة متاحة من قسم الطاقة.' : 'افتح الأداة للاطلاع على التفاصيل قبل التنفيذ.';
}
function updateExecute() {
  $('#execute').disabled = running || !system.windows || !$('#ack').checked || currentAction?.disabled;
  $('#execute').textContent = running ? 'هناك عملية قيد التشغيل…' : !system.windows ? 'التنفيذ يحتاج نسخة Windows' : currentAction?.disabled ? 'غير متاح في الملف الأصلي' : 'تشغيل الخيار ←';
}
function showDetail(id) {
  currentAction = catalog.actions.find(a => a.id === id);
  const a = currentAction;
  $('#detail-category').textContent = category(a.category).title;
  $('#detail-title').textContent = a.title; $('#detail-description').textContent = a.description;
  const warnings = make('ul'); for (const warning of a.warnings) warnings.append(make('li', '', warning));
  $('#detail-warnings').replaceChildren(warnings); $('#detail-warnings').hidden = !a.warnings.length;
  $('#detail-notes').textContent = a.notes; $('#detail-notes').hidden = !a.notes;
  $('#detail-requires').textContent = a.requires.length ? 'ملفات مطلوبة قبل التنفيذ:\n' + a.requires.join('\n') + '\nتتوفر معلوماتها من «الملفات المساعدة» أسفل النافذة.' : '';
  $('#detail-requires').hidden = !a.requires.length;
  $('#source-lines').textContent = a.source.length ? 'الأسطر الأصلية: ' + a.source.map(r => r.join('–')).join('، ') : 'أداة Windows مساعدة';
  $('#command-preview').textContent = a.commands || 'لا يوجد أمر قابل للتشغيل لهذا الخيار في المصدر.';
  $('.command-preview').open = false;
  $('#ack').checked = false; $('#ack-label').hidden = !!a.disabled;
  updateExecute(); $('#detail-dialog').showModal();
}
async function execute() {
  if (!currentAction || !$('#ack').checked || running || !system.windows || currentAction.disabled) return;
  const action = currentAction; running = true; updateExecute();
  $('#activity-summary').textContent = `بانتظار تأكيد التشغيل وصلاحية المسؤول: ${action.title}`;
  $('#log').textContent = 'Waiting for Windows authorization…';
  try {
    const result = await window.desktop.run(action.id);
    if (result.cancelled) { running = false; $('#activity-summary').textContent = 'أُلغي الطلب؛ لم تبدأ عملية التنفيذ.'; updateExecute(); return; }
    $('#detail-dialog').close();
    // A very fast operation may have delivered its completion event already.
    if (running) { $('#activity-summary').textContent = `قيد التشغيل: ${action.title}. قد تظهر مطالبة UAC من Windows.`; $('#activity-indicator').className = 'activity-indicator running'; }
    $('#log-details').open = true;
  } catch (error) { running = false; updateExecute(); $('#activity-summary').textContent = 'لم يبدأ التنفيذ: ' + error.message; toast(error.message); }
}
function done(result) {
  running = false; updateExecute();
  $('#activity-indicator').className = 'activity-indicator' + (result.code === 0 ? '' : ' error');
  const message = result.code === 0 ? 'انتهت الأوامر دون رصد رمز خطأ. راجع النتائج؛ لم يُقَس الأداء ولم تُفحص كل قيمة.' : `انتهت العملية مع أخطاء أو تعذّر تشغيلها (رمز ${result.code}). راجع السجل؛ قد تكون بعض التعديلات طُبّقت.`;
  $('#activity-summary').textContent = message;
  $('#log').textContent += '\n\n' + result.message + (result.directory ? '\nLogs: ' + result.directory : '');
  toast(result.code === 0 ? 'انتهت العملية. راجع سجل التنفيذ.' : 'تحتاج العملية إلى مراجعة سجل الأخطاء.');
}
buildNavigation(); saveFavorites(); render();
$('#actions-stat').textContent = catalog.actions.length; $('#sections-stat').textContent = catalog.categories.length;
$('#search').addEventListener('input', render);
$('#show-all').addEventListener('click', () => chooseCategory('all'));
$('#browse').addEventListener('click', () => { chooseCategory('all'); $('#search').focus(); });
$('#restore-shortcut').addEventListener('click', () => showDetail('createrp'));
document.querySelectorAll('.close-dialog').forEach(e => e.addEventListener('click', () => $('#detail-dialog').close()));
$('#ack').addEventListener('change', updateExecute); $('#execute').addEventListener('click', execute);
$('#close-info').addEventListener('click', () => $('#info-dialog').close());
$('#dismiss-info').addEventListener('click', () => $('#info-dialog').close());
$('#about').addEventListener('click', () => info('عن AHME Tools', `واجهة عربية لملف ahme.cmd المرفق، المبني على AzizUtility Tool.\n\n${catalog.actions.length} خيارًا في ${catalog.categories.length} قسمًا. الملف الأصلي محفوظ داخل مجلد original دون تغيير.\n\nالبرنامج لا يَعِد بتحسين الأداء، ولا يطبّق تعديلات عند فتحه. بعض أوامر المصدر قديمة أو بها أخطاء؛ تُعرض الملاحظات ويُحفظ ناتج التنفيذ. زر التراجع يشغّل قيم السكربت، وليس نسخة احتياطية من جهازك.\n\nالواجهة اختُبرت آليًا على Linux؛ أوامر Windows تحتاج تجربة على جهاز Windows ويفضل جهاز افتراضي قبل الاستخدام على جهازك الأساسي.`));
$('#resources').addEventListener('click', () => info('الملفات المساعدة', 'لم يتضمن المرفق ملفات PowerPlan_GUID.pow أو autoruns.exe.\n\nخيار استيراد خطة الطاقة يحتاج:\nC:\\AzizTools\\PowerPlan_GUID.pow\n\nخيار إدارة بدء التشغيل يحتاج:\nC:\\AzizTools\\autoruns.exe\n\nالرابط التالي هو رابط الأرشيف الموجود في ملفك الأصلي. افتحه فقط إذا كنت تثق بمصدره، ثم افحص محتوياته وضع الملفات المطلوبة في المسار أعلاه. لا ينزّل البرنامج ملفات تنفيذية أو يشغّلها تلقائيًا.\n\nبقية الخيارات لا تتطلب هذا الأرشيف.', true));
$('#info-link').addEventListener('click', async () => { if (!window.desktop) return toast('الرابط متاح من تطبيق سطح المكتب.'); try { await window.desktop.external('resources'); } catch(e) { toast(e.message); } });
$('#discord').addEventListener('click', async () => { if (!window.desktop) return toast('فتح الرابط متاح من تطبيق سطح المكتب.'); try { await window.desktop.external('discord'); } catch(e) { toast(e.message); } });
$('#open-logs').addEventListener('click', async () => { if (!window.desktop) return toast('تُحفظ السجلات عند تشغيل الأوامر في تطبيق Windows.'); try { await window.desktop.logs(); } catch(e) { toast(e.message); } });
document.addEventListener('keydown', event => { if (event.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) && !document.querySelector('dialog[open]')) { event.preventDefault(); $('#search').focus(); } });
if (window.desktop) {
  window.desktop.onLog(text => { $('#log').textContent = text; });
  window.desktop.onDone(done);
  window.desktop.info().then(data => {
    system = data;
    $('#system-name').textContent = data.platform; $('#system-subtitle').textContent = data.cpu;
    $('#ram').replaceChildren(document.createTextNode(data.ram + ' '), make('small', '', 'GB'));
    $('#platform').textContent = data.windows ? 'Windows · تنفيذ عند الطلب' : 'معاينة · النظام غير مدعوم';
    if (data.windows) {
      $('#environment-notice').replaceChildren(make('span', '', '◎'), make('p', '', 'ابدأ بنقطة استعادة قبل التعديلات الحساسة. يطلب كل تشغيل تأكيدك وصلاحية المسؤول، وتُحفظ مخرجاته في السجل.'));
    }
    updateExecute();
  }).catch(error => toast(error.message));
}
