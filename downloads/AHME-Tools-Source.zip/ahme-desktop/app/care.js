'use strict';
(() => {
  const el = id => document.getElementById(id);
  const theme = el('theme'), allowed = ['aurora', 'ocean', 'violet', 'ember'];
  let saved; try { saved = localStorage.getItem('ahme-theme'); } catch {}
  theme.value = allowed.includes(saved) ? saved : 'aurora';
  function applyTheme() { document.documentElement.dataset.theme = theme.value; }
  applyTheme(); theme.addEventListener('change', () => { applyTheme(); try { localStorage.setItem('ahme-theme', theme.value); } catch {} });
  const services = [
    ['WSearch', 'فهرسة البحث', 'إيقافها قد يجعل البحث أبطأ أو غير مكتمل.'],
    ['Spooler', 'خدمة الطباعة', 'إيقافها يمنع الطباعة، بما فيها الطباعة إلى PDF.'],
    ['XblAuthManager', 'دخول Xbox', 'قد تحتاجها لتسجيل الدخول إلى Xbox وألعابه.'],
    ['XboxNetApiSvc', 'شبكة Xbox', 'قد تحتاجها للألعاب الجماعية وخدمات Xbox.']
  ];
  let supported = false, pending = false, chosen = null, plan = null, serviceStates = {};
  const bytes = n => n >= 1024 ** 3 ? (n / 1024 ** 3).toFixed(2) + ' GB' : (n / 1024 ** 2).toFixed(1) + ' MB';
  function status(message, state = '') { el('care-status').textContent = message; el('care-status').dataset.state = state; }
  function controls() {
    document.querySelectorAll('.care-native').forEach(button => { button.disabled = !supported || pending; });
    el('trim-app').disabled = el('close-app').disabled = !supported || pending || !chosen;
    el('scan-cache').disabled = !supported || pending || !document.querySelector('[name=cache]:checked');
    el('clean-cache').disabled = !supported || pending || !plan?.count;
    document.querySelectorAll('[name=cache],[name=application]').forEach(input => { input.disabled = pending; });
    document.querySelectorAll('[data-service]').forEach(button => {
      const state = serviceStates[button.dataset.service];
      button.disabled = !supported || pending || (button.dataset.operation === 'stop' ? state !== 'Running' : state !== 'Stopped');
    });
  }
  async function operation(message, action) {
    if (pending || !supported) return;
    pending = true; controls(); status(message, 'busy');
    try { await action(); } catch (error) { status('تعذرت العملية: ' + error.message, 'error'); }
    finally { pending = false; controls(); }
  }
  function appsList(apps) {
    chosen = null; el('apps-list').replaceChildren();
    if (!apps.length) el('apps-list').append(make('div', 'care-empty', 'لا توجد تطبيقات ظاهرة مناسبة للتحكم، أو أنها محمية.'));
    for (const app of apps) {
      const row = make('label', 'app-row'), input = make('input'); input.type = 'radio'; input.name = 'application'; input.value = app.id;
      input.addEventListener('change', () => { chosen = { id: app.id, start: app.start }; controls(); });
      const name = make('strong', '', app.name); name.dir = 'auto';
      row.append(input, name, make('small', '', bytes(app.memory))); el('apps-list').append(row);
    }
  }
  el('refresh-apps').addEventListener('click', () => operation('جارٍ قراءة التطبيقات الظاهرة…', async () => {
    const result = await window.desktop.care('apps'); appsList(result.apps); status('اختر تطبيقًا من القائمة. لا تُعرض خدمات النظام أو التطبيقات المحمية.');
  }));
  for (const [id, op] of [['trim-app', 'trim'], ['close-app', 'close']]) {
    el(id).addEventListener('click', () => operation('بانتظار التأكيد ونتيجة Windows…', async () => {
      const result = await window.desktop.care(op, chosen);
      if (result.cancelled) return status('أُلغي الطلب؛ لم تبدأ العملية.');
      status(op === 'trim' ? `ذاكرة التطبيق: ${bytes(result.before)} قبل → ${bytes(result.after)} بعد. قراءة لحظية وقد ترتفع مجددًا.` : result.requested ? 'أُرسل طلب الإغلاق. راجع التطبيق؛ قد يطلب حفظ ملفاتك.' : 'لم يقبل التطبيق طلب الإغلاق. يمكنك إغلاقه يدويًا.', op === 'close' && !result.requested ? 'error' : 'success');
      chosen = null;
      el('apps-list').replaceChildren(make('div', 'care-empty', 'حدّث القائمة لقراءة حالة التطبيقات الجديدة.'));
      await refreshMetrics();
    }));
  }
  document.querySelectorAll('[name=cache]').forEach(input => input.addEventListener('change', () => { plan = null; el('scan-result').textContent = 'تغيّر الاختيار؛ افحص الملفات من جديد.'; controls(); }));
  el('scan-cache').addEventListener('click', () => operation('جارٍ فحص الكاش؛ لم يبدأ الحذف…', async () => {
    plan = null;
    const categories = [...document.querySelectorAll('[name=cache]:checked')].map(input => input.value);
    plan = await window.desktop.care('scan', { categories });
    el('scan-result').textContent = `${plan.count} ملف · ${bytes(plan.bytes)} قابلة للحذف.${plan.skipped ? ' مواقع تعذرت قراءتها أو روابط متجاوزة: ' + plan.skipped + '.' : ''}${plan.truncated ? ' الفحص جزئي بسبب حد الملفات؛ يمكنك الفحص مجددًا بعد التنظيف.' : ''} المعاينة صالحة 5 دقائق.`;
    status('انتهى الفحص دون حذف. راجع النتيجة ثم اختر الحذف إذا أردت.');
  }));
  el('clean-cache').addEventListener('click', () => operation('بانتظار التأكيد ثم تنظيف الملفات المفحوصة…', async () => {
    const token = plan.token;
    // Invalidate UI plan on failure as well: rescan before any retry.
    plan = null;
    const result = await window.desktop.care('clean', { token });
    if (result.cancelled) { el('scan-result').textContent = 'أُلغي التنظيف. افحص مجددًا للمتابعة.'; return status('أُلغي الطلب؛ لم يبدأ الحذف.'); }
    const message = `حُذف ${result.deleted} ملف (${bytes(result.bytes)}). ملفات متجاوزة: ${result.skipped}.`;
    el('scan-result').textContent = message; status(message, 'success');
  }));
  function drawServices() {
    el('services-list').replaceChildren();
    for (const [id, name, description] of services) {
      const item = make('div', 'service-card'), state = serviceStates[id];
      item.append(make('h3', '', name), make('p', '', description), make('span', 'service-state', state === 'Running' ? '● تعمل الآن' : state === 'Stopped' ? '○ متوقفة' : state || 'الحالة غير مقروءة'));
      const actions = make('div', 'care-actions');
      for (const [action, label] of [['stop', 'إيقاف مؤقت'], ['start', 'تشغيل']]) {
        const button = make('button', 'button light', label); button.dataset.service = id; button.dataset.operation = action;
        button.setAttribute('aria-label', label + ': ' + name);
        button.addEventListener('click', () => operation('بانتظار التأكيد وصلاحية المسؤول…', async () => {
          const result = await window.desktop.care('service', { id, action });
          if (result.cancelled) return status('أُلغي الطلب؛ لم تتغير الخدمة.');
          serviceStates[id] = result.status; drawServices();
          status(`${name}: ${result.status === 'Stopped' ? 'متوقفة' : result.status === 'Running' ? 'تعمل' : result.status}. لم يتغير نوع بدء التشغيل.`, 'success');
        }));
        actions.append(button);
      }
      item.append(actions); el('services-list').append(item);
    }
    controls();
  }
  el('refresh-services').addEventListener('click', () => operation('جارٍ قراءة حالة الخدمات…', async () => {
    const result = await window.desktop.care('services');
    serviceStates = Object.fromEntries(services.map(([id]) => [id, 'غير مثبتة']));
    for (const item of result.services) serviceStates[item.id] = item.status;
    drawServices(); status('تم تحديث الحالات. لا تحتاج إيقاف جميع الخدمات؛ اختر حسب استخدامك.');
  }));
  document.querySelectorAll('[data-setting]').forEach(button => button.addEventListener('click', () => operation('جارٍ فتح إعدادات Windows…', async () => {
    await window.desktop.settings(button.dataset.setting); status('فُتحت إعدادات Windows. التغييرات تُختار من هناك.');
  })));
  let measuring = false;
  async function refreshMetrics() {
    if (!supported || measuring || document.hidden) return;
    measuring = true;
    try {
      const data = await window.desktop.care('metrics');
      const percent = Math.round((data.total - data.free) / data.total * 100);
      el('memory-used').textContent = percent + '%'; el('memory-gauge').value = percent;
      el('memory-free').textContent = `${bytes(data.free)} متاحة من ${bytes(data.total)}`;
      el('cpu-used').textContent = data.cpu === null ? '…' : data.cpu + '%'; el('cpu-gauge').value = data.cpu ?? 0;
      el('metrics-state').textContent = 'قراءة فعلية · تحديث كل 3 ثوانٍ';
    } catch { el('metrics-state').textContent = 'تعذّر تحديث القراءات'; el('cpu-used').textContent = el('memory-used').textContent = '—'; el('cpu-gauge').value = el('memory-gauge').value = 0; }
    finally { measuring = false; }
  }
  drawServices(); controls();
  if (window.desktop?.care) window.desktop.info().then(data => {
    supported = data.windows; controls();
    if (supported) { refreshMetrics(); setInterval(refreshMetrics, 3000); document.addEventListener('visibilitychange', refreshMetrics); }
  }).catch(error => status(error.message, 'error'));
})();
