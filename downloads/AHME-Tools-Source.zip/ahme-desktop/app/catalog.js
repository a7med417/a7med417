window.AHME_CATALOG = {
  "sourceSha256": "91c919f702e897932726ecbe06cc2c53db809dbb5352e443474e08944442264b",
  "categories": [
    {
      "id": "general",
      "title": "التحسينات العامة",
      "icon": "◈"
    },
    {
      "id": "windows",
      "title": "إعدادات Windows",
      "icon": "▦"
    },
    {
      "id": "input",
      "title": "الماوس والكيبورد",
      "icon": "⌨"
    },
    {
      "id": "clean",
      "title": "تنظيف الجهاز",
      "icon": "◇"
    },
    {
      "id": "memory",
      "title": "الذاكرة RAM",
      "icon": "▤"
    },
    {
      "id": "gpu",
      "title": "كرت الشاشة",
      "icon": "▣"
    },
    {
      "id": "cpu",
      "title": "المعالج",
      "icon": "◉"
    },
    {
      "id": "usb",
      "title": "منافذ USB",
      "icon": "⌁"
    },
    {
      "id": "power",
      "title": "الطاقة",
      "icon": "ϟ"
    },
    {
      "id": "debloat",
      "title": "الخدمات والتطبيقات",
      "icon": "⊞"
    },
    {
      "id": "storage",
      "title": "التخزين",
      "icon": "▰"
    },
    {
      "id": "repair",
      "title": "إصلاح النظام",
      "icon": "✚"
    },
    {
      "id": "fullscreen",
      "title": "ملء الشاشة",
      "icon": "⛶"
    },
    {
      "id": "revert",
      "title": "التراجع والاستعادة",
      "icon": "↶"
    },
    {
      "id": "tools",
      "title": "الأدوات المساعدة",
      "icon": "⚙"
    }
  ],
  "actions": [
    {
      "id": "comprehensive",
      "category": "general",
      "title": "تطبيق التحسينات الشاملة",
      "description": "تعديلات السجل والإقلاع ونظام الملفات الواردة في السكربت.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز."
      ],
      "notes": "توجد معاملات أصلية غير معتادة مثل Disablinglastaccess؛ تظهر أخطاء تنفيذها في السجل ولا تُخفى.",
      "requires": [],
      "source": [
        [
          383,
          519
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"FpsAll\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"FpsStatusGames\" /t REG_DWORD /d \"10\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"FpsStatusGamesAll\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"GameFluidity\" /t REG_DWORD /d \"1\" /f\nbcdedit /set Disabledynamictick yes\nbcdedit /deletevalue useplatformclock\nbcdedit /set useplatformtick yes\nfsutil behavior set memoryusage 2\nfsutil behavior set mftzone 4\nfsutil behavior set Disablinglastaccess 1\nfsutil behavior set Disabledeletenotify 1\nfsutil behavior set encryptpagingfile 0\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Affinity\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Background Only\" /t REG_SZ /d \"False\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"BackgroundPriority\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Clock Rate\" /t REG_DWORD /d \"10000\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"GPU Priority\" /t REG_DWORD /d \"8\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Priority\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Scheduling Category\" /t REG_SZ /d \"Medium\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"SFIO Priority\" /t REG_SZ /d \"High\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Latency Sensitive\" /t REG_SZ /d \"True\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Affinity\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Background Only\" /t REG_SZ /d \"False\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"BackgroundPriority\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Clock Rate\" /t REG_DWORD /d \"10000\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"GPU Priority\" /t REG_DWORD /d \"8\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Priority\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Scheduling Category\" /t REG_SZ /d \"High\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"SFIO Priority\" /t REG_SZ /d \"High\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Latency Sensitive\" /t REG_SZ /d \"True\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl\" /v \"Win32PrioritySeparation\" /t REG_DWORD /d \"38\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl\" /v \"IRQ8Priority\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\PriorityControl\" /v \"IRQ8Priority\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl\" /v \"IRQ16Priority\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\PriorityControl\" /v \"IRQ16Priority\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"AutoEndTasks\" /t REG_SZ /d \"1\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"HungAppTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"WaitToKillAppTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"LowLevelHooksTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"MenuShowDelay\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"WaitToKillServiceTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability\" /v \"TimeStampInterval\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability\" /v \"IoPriority\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\csrss.exe\\PerfOptions\" /v \"CpuPriorityClass\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\csrss.exe\\PerfOptions\" /v \"IoPriority\" /t REG_DWORD /d \"3\" /f\nbcdedit /set configaccesspolicy Default\nbcdedit /set MSI Default\nbcdedit /set usephysicaldestination No\nbcdedit /set usefirmwarepcisettings No\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\DXGKrnl\" /v \"MonitorLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\DXGKrnl\" /v \"MonitorRefreshLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatencyCheckEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"Latency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceDefault\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceFSVP\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyTolerancePerfOverride\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceScreenOffIR\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceVSyncEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"RtlCapabilityCheckLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyActivelyUsed\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleLongTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleShortTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleVeryLongTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle0\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle0MonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle1\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle1MonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceMemory\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceNoContextMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceOther\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceTimerPeriod\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceActivelyUsed\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"Latency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MaxIAverageGraphicsLatencyInOneBucket\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MiracastPerfTrackGraphicsLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MonitorLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MonitorRefreshLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"TransitionLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\" /v \"SystemResponsiveness\" /t REG_DWORD /d \"0\" /f",
      "sha256": "c94f43ecaba608afcff42a3fa8f5716ec50218c97982cf58bf945180512886f0"
    },
    {
      "id": "kbm1",
      "category": "input",
      "title": "تعديل الماوس والكيبورد",
      "description": "تطبيق قيم الاستجابة وإعدادات أجهزة الإدخال من الملف الأصلي.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          749,
          798
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\Control Panel\\Accessibility\\Keyboard Response\" /v \"Flags\" /t REG_SZ /d \"122\" /f\nReg.exe add \"HKCU\\Control Panel\\Accessibility\\ToggleKeys\" /v \"Flags\" /t REG_SZ /d \"58\" /f\nReg.exe add \"HKCU\\Control Panel\\Accessibility\\StickyKeys\" /v \"Flags\" /t REG_SZ /d \"506\" /f\nReg.exe add \"HKCU\\Control Panel\\Accessibility\\MouseKeys\" /v \"Flags\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\Mouse\" /v \"MouseSpeed\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\Mouse\" /v \"MouseThreshold1\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\Mouse\" /v \"MouseThreshold2\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\Mouse\" /v \"MouseSensitivity\" /t REG_SZ /d \"10\" /f\nReg.exe add \"HKCU\\Control Panel\\Keyboard\" /v \"KeyboardDelay\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\Keyboard\" /v \"KeyboardSpeed\" /t REG_SZ /d \"31\" /f",
      "sha256": "bb9db097d806bc5f76c057fac53ba94fd148ff7fe7ebb91366885cf076631bf4"
    },
    {
      "id": "w16",
      "category": "windows",
      "title": "تعطيل موجز النشاط",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "أصلح ربط القائمة: كانت تشير إلى w6 غير الموجود؛ هذا هو قسم موجز النشاط w16.",
      "requires": [],
      "source": [
        [
          1075,
          1095
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Feeds\" /v \"EnableFeeds\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\" /v \"AllowNewsAndInterests\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnableActivityFeed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"EnableActivityFeed\" /t REG_DWORD /d \"0\" /f",
      "sha256": "fa1ae63fa281eecc01a5358a5792cc7c5fca18d43af23f371d504783fc96c205"
    },
    {
      "id": "w3",
      "category": "windows",
      "title": "إعدادات المؤثرات البصرية",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1096,
          1109
        ]
      ],
      "commands": "%windir%\\system32\\SystemPropertiesPerformance.exe",
      "sha256": "4f67fe97021686c6ecf4d37c74dba7914d9418573b1e7b188e5fc88d3a3ff46d"
    },
    {
      "id": "w2",
      "category": "windows",
      "title": "تعطيل الإشعارات",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1146,
          1171
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PushNotifications\" /v \"ToastEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\" /v \"NOC_GLOBAL_SETTING_ALLOW_NOTIFICATION_SOUND\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\" /v \"NOC_GLOBAL_SETTING_ALLOW_CRITICAL_TOASTS_ABOVE_LOCK\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\QuietHours\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.AutoPlay\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.LowDisk\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.Print.Notification\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.SecurityAndMaintenance\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.WiFiNetworkManager\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer\" /v \"DisableNotificationCenter\" /t REG_DWORD /d \"1\" /f",
      "sha256": "868318335658ba25eb66af6d29ba5647d22905583c089c2d72d015434f85b0a8"
    },
    {
      "id": "w4",
      "category": "windows",
      "title": "تعديل بحث Windows",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1110,
          1145
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"BingSearchEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitInkCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitTextCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Personalization\\Settings\" /v \"AcceptedPrivacyPolicy\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"CortanaCapabilities\" /t REG_SZ /d \"\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"IsAssignedAccess\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"IsWindowsHelloActive\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d 0 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchPrivacy\" /t REG_DWORD /d 3 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchSafeSearch\" /t REG_DWORD /d 3 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d 0 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d 0 /f\nReg.exe add \"HKLM\\Software\\Microsoft\\PolicyManager\\default\\Experience\\AllowCortana\" /v \"value\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\SearchCompanion\" /v \"DisableContentFileUpdates\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCloudSearch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortanaAboveLock\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchPrivacy\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DisableWebSearch\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DoNotUseWebResults\" /t REG_DWORD /d \"1\" /f",
      "sha256": "f6321b5b520d7b1e47de0e26b5be42622112efeb898e8ebd307ffc4a3dd905a6"
    },
    {
      "id": "w5",
      "category": "windows",
      "title": "تعطيل Bluetooth",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "سيؤثر في سماعات وأجهزة الإدخال المتصلة بالبلوتوث."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1172,
          1189
        ]
      ],
      "commands": "Reg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BTAGService\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bthserv\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BthAvctpSvc\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BluetoothUserService\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "683be91d6e42275225bb7d4c80ba8f86782e16b0f167fc43b6eef817985cd45e"
    },
    {
      "id": "w1",
      "category": "windows",
      "title": "تعطيل الشفافية",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "اسم القيمة EnablingTransparency مكتوب هكذا في الأصل؛ لم نغيّره إلى قيمة أخرى أو نضمن فعاليته.",
      "requires": [],
      "source": [
        [
          1487,
          1503
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize\" /v \"EnablingTransparency\" /t REG_DWORD /d \"0\" /f",
      "sha256": "3d0fe847145d89a6274627a66647877fbcfea53b3c1d94fc108c25390c7b8e21"
    },
    {
      "id": "w7",
      "category": "windows",
      "title": "تعطيل تقارير الأخطاء",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1190,
          1208
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"DoReport\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"LoggingDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\PCHealth\\ErrorReporting\" /v \"DoReport\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d \"1\" /f",
      "sha256": "9d941eb0678b69c6a92a6b7a4cffea8714579c5c0238a7269de5b8e8641972ae"
    },
    {
      "id": "w8",
      "category": "windows",
      "title": "تعطيل مزامنة الإعدادات",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1209,
          1252
        ]
      ],
      "commands": "Reg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\" /v \"SyncPolicy\" /t Reg_DWORD /d \"5\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Accessibility\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\AppSync\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\BrowserSettings\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Credentials\" /v \"Enabled\" /t Reg_DWORD /d \"\"0\"\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\DesktopTheme\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Language\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\PackageState\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Personalization\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\StartLayout\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Windows\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableAppSyncSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableAppSyncSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableApplicationSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableApplicationSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableCredentialsSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableCredentialsSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableDesktopThemeSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableDesktopThemeSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisablePersonalizationSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisablePersonalizationSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableStartLayoutSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableStartLayoutSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSyncOnPaidNetwork\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWebBrowserSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWebBrowserSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWindowsSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWindowsSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f",
      "sha256": "cc603fe011a3a140ea5c935a9fc0a7e14ae184aa23d255d984fc1593c6576cf6"
    },
    {
      "id": "w9",
      "category": "windows",
      "title": "تعطيل التشخيص",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1253,
          1271
        ]
      ],
      "commands": "sc stop DiagTrack\nsc config DiagTrack start= Disabled\nsc stop dmwappushservice\nsc config dmwappushservice start= Disabled\nsc stop diagnosticshub.standardcollector.service\nsc config diagnosticshub.standardcollector.service start= Disabled",
      "sha256": "2c2fbbec814efd1c072604fe9fb8d8fcc45aab07fdefaa469b7efbc1728a5738"
    },
    {
      "id": "w10",
      "category": "windows",
      "title": "تعطيل تطبيقات الخلفية",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1468,
          1486
        ]
      ],
      "commands": "Reg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications\" /v \"GlobalUserDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"BackgroundAppGlobalToggle\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\bam\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\dam\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "3b7d4228b6d57850b46cefd1c67d4ea004d598ad4ed9209c68f99281214b6b09"
    },
    {
      "id": "w11",
      "category": "windows",
      "title": "تعطيل التجارب",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1297,
          1312
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System\" /v \"AllowExperimentation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\default\\System\\AllowExperimentation\" /v \"value\" /t REG_DWORD /d \"0\" /f",
      "sha256": "7d30ad5ea2457a3275ac5a73a35d64e87f71f0b9d647e959aa4a174f5645489a"
    },
    {
      "id": "gmodeon",
      "category": "windows",
      "title": "تفعيل وضع الألعاب",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1349,
          1364
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AllowAutoGameMode\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AutoGameModeEnabled\" /t REG_DWORD /d \"1\" /f",
      "sha256": "60fcb0d6611c70cad0f0347e615e2fa1b201d76f52a84ac7ec1486de667d425a"
    },
    {
      "id": "gmodeoff",
      "category": "windows",
      "title": "إيقاف وضع الألعاب",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1365,
          1380
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AllowAutoGameMode\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AutoGameModeEnabled\" /t REG_DWORD /d \"0\" /f",
      "sha256": "5e9c546023fc13dc0065f5e556aac203550190bbacd16db4b359bf8144b3d1e2"
    },
    {
      "id": "w13",
      "category": "windows",
      "title": "تعطيل الصيانة التلقائية",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1381,
          1395
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance\" /v \"MaintenanceDisabled\" /t REG_DWORD /d \"1\" /f",
      "sha256": "5d94e9c1f370f08f752646cfedd6a8386e07cf1df61ae06a7f8471634c0f0e3e"
    },
    {
      "id": "w14",
      "category": "windows",
      "title": "تعطيل التتبع وبعض التشخيص",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1504,
          1534
        ]
      ],
      "commands": "Reg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy\" /v \"TailoredExperiencesWithDiagnosticDataEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Diagnostics\\DiagTrack\" /v \"ShowedToastAtLevel\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Input\\TIPC\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"UploadUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"PublishUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Attachments\" /v \"SaveZoneInformation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Diagnostics\\Performance\" /v \"DisablediagnosticTracing\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WDI\\{9c5a40da-b965-4fc3-8781-88dd50a6299d}\" /v \"ScenarioExecutionEnabled\" /t REG_DWORD /d \"0\" /f\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\" /Disable",
      "sha256": "32e6b180b712712f300664b207df9f459d60f2eef7c52e4b6f875f18d2f4e69c"
    },
    {
      "id": "w15",
      "category": "windows",
      "title": "تعطيل النوافذ المنبثقة",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1396,
          1416
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\" /v \"DisallowShaking\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\" /v \"EnableBalloonTips\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\" /v \"ShowSyncProviderNotifications\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\userNotificationListener\" /v \"Value\" /t REG_SZ /d \"Deny\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\AdvertisingInfo\" /v \"DisabledByGroupPolicy\" /t REG_DWORD /d \"1\" /f",
      "sha256": "725769cf7d598a9e375c51ea7c66a3dfb43dc8bbbea0490b1ba30243e30391a8"
    },
    {
      "id": "w20",
      "category": "windows",
      "title": "تعديل أحداث التدقيق",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "أصلح ربط القائمة: كان يشغّل الشفافية بدل قسم أحداث التدقيق w20. بعض معاملات Auditpol الأصلية متعارضة وتحتاج مراجعة.",
      "requires": [],
      "source": [
        [
          1272,
          1296
        ]
      ],
      "commands": "Auditpol /set /subcategory:\"Process Termination\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"RPC Events\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Filtering Platform Connection\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"DPAPI Activity\" /failure:Disable /failure:Disable\nAuditpol /set /subcategory:\"IPsec Driver\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Other System Events\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Security State Change\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Security System Extension\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"System Integrity\" /failure:Disable /failure:Enable\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\AutoLogger-Diagtrack-Listener\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\DiagLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\Diagtrack-Listener\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiSession\" /v \"Start\" /t REG_DWORD /d \"0\" /f",
      "sha256": "a79f26e2299cc1a6ec03948dfe517960f77084b9618543cb98fc2d067baca38b"
    },
    {
      "id": "w17",
      "category": "windows",
      "title": "تعطيل SmartScreen",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز."
      ],
      "notes": "بعض أسماء القيم في الأصل مكتوبة EnablingSmartScreen وEnablingWebContentEvaluation؛ قد لا يتعرف Windows عليها.",
      "requires": [],
      "source": [
        [
          1432,
          1446
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingSmartScreen\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\" /v \"SmartScreenEnabled\" /t REG_SZ /d \"Off\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AppHost\" /v \"EnablingWebContentEvaluation\" /t REG_DWORD /d \"0\" /f",
      "sha256": "a4d136c2cb85ac924eb29f556e503e1a07a3ba724c67562204d1ea64f7738180"
    },
    {
      "id": "w18",
      "category": "windows",
      "title": "منع إعادة تثبيت التطبيقات",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1447,
          1467
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"PreInstalledAppsEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"SilentInstalledAppsEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"OemPreInstalledAppsEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"ContentDeliveryAllowed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"SubscribedContentEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"PreInstalledAppsEverEnabled\" /t REG_DWORD /d \"0\" /f",
      "sha256": "d764b3714f40608b4e78a3064182558d5eee6918bd356a816487e947eb276c66"
    },
    {
      "id": "w19",
      "category": "windows",
      "title": "تعطيل التجارب المشتركة",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1417,
          1431
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CDP\" /v \"CdpSessionUserAuthzPolicy\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CDP\" /v \"NearShareChannelUserAuthzPolicy\" /t REG_DWORD /d \"0\" /f",
      "sha256": "12f6f017ece7b0a44664a8e15d867907fa1e508e9dcfec7ece42f2e0c7c38c1b"
    },
    {
      "id": "allwindows",
      "category": "windows",
      "title": "تطبيق مجموعة Windows",
      "description": "المجموعة الأصلية؛ اختر وضع الألعاب من الخيارات المنفصلة عند الحاجة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز."
      ],
      "notes": "تم فصل اختيار وضع الألعاب لتجنب تسميات gmodeON/gmodeOFF المكررة في الأصل. قد تفشل معاملات Auditpol الأصلية.",
      "requires": [],
      "source": [
        [
          1601,
          1778
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"BingSearchEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitInkCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitTextCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Personalization\\Settings\" /v \"AcceptedPrivacyPolicy\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"CortanaCapabilities\" /t REG_SZ /d \"\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"IsAssignedAccess\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"IsWindowsHelloActive\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d 0 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchPrivacy\" /t REG_DWORD /d 3 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchSafeSearch\" /t REG_DWORD /d 3 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d 0 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d 0 /f\nReg.exe add \"HKLM\\Software\\Microsoft\\PolicyManager\\default\\Experience\\AllowCortana\" /v \"value\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\SearchCompanion\" /v \"DisableContentFileUpdates\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCloudSearch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortanaAboveLock\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchPrivacy\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DisableWebSearch\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DoNotUseWebResults\" /t REG_DWORD /d \"1\" /f\nAuditpol /set /subcategory:\"Process Termination\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"RPC Events\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Filtering Platform Connection\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"DPAPI Activity\" /failure:Disable /failure:Disable\nAuditpol /set /subcategory:\"IPsec Driver\" /success:\t /failure:Enable\nAuditpol /set /subcategory:\"Other System Events\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Security State Change\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Security System Extension\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"System Integrity\" /failure:Disable /failure:Enable\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\AutoLogger-Diagtrack-Listener\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\DiagLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\Diagtrack-Listener\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiSession\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System\" /v \"AllowExperimentation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\default\\System\\AllowExperimentation\" /v \"value\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Feeds\" /v \"EnablingFeeds\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\" /v \"AllowNewsAndInterests\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingActivityFeed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingActivityFeed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance\" /v \"MaintenanceDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PushNotifications\" /v \"ToastEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\" /v \"NOC_GLOBAL_SETTING_ALLOW_NOTIFICATION_SOUND\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\" /v \"NOC_GLOBAL_SETTING_ALLOW_CRITICAL_TOASTS_ABOVE_LOCK\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\QuietHours\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.AutoPlay\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.LowDisk\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.Print.Notification\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.SecurityAndMaintenance\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.WiFiNetworkManager\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer\" /v \"DisableNotificationCenter\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BTAGService\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bthserv\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BthAvctpSvc\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BluetoothUserService\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nsc config DiagTrack start= Disabled\nsc config dmwappushservice start= Disabled\nsc config DPS start= Disabled\nsc config diagnosticshub.standardcollector.service start= Disabled\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"DoReport\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"LoggingDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\PCHealth\\ErrorReporting\" /v \"DoReport\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CDP\" /v \"CdpSessionUserAuthzPolicy\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CDP\" /v \"NearShareChannelUserAuthzPolicy\" /t REG_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\" /v \"SyncPolicy\" /t Reg_DWORD /d \"5\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Accessibility\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\AppSync\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\BrowserSettings\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Credentials\" /v \"Enabled\" /t Reg_DWORD /d \"\"0\"\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\DesktopTheme\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Language\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\PackageState\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Personalization\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\StartLayout\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Windows\" /v \"Enabled\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableAppSyncSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableAppSyncSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableApplicationSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableApplicationSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableCredentialsSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableCredentialsSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableDesktopThemeSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableDesktopThemeSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisablePersonalizationSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisablePersonalizationSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableStartLayoutSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableStartLayoutSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSyncOnPaidNetwork\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWebBrowserSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWebBrowserSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWindowsSettingSync\" /t Reg_DWORD /d \"2\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWindowsSettingSyncUserOverride\" /t Reg_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingSmartScreen\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\" /v \"SmartScreenEnabled\" /t REG_SZ /d \"Off\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AppHost\" /v \"EnablingWebContentEvaluation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"PreInstalledAppsEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"SilentInstalledAppsEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"OemPreInstalledAppsEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"ContentDeliveryAllowed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"SubscribedContentEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"PreInstalledAppsEverEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications\" /v \"GlobalUserDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"BackgroundAppGlobalToggle\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\bam\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\dam\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize\" /v \"EnablingTransparency\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AllowAutoGameMode\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AutoGameModeEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy\" /v \"TailoredExperiencesWithDiagnosticDataEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Diagnostics\\DiagTrack\" /v \"ShowedToastAtLevel\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Input\\TIPC\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"UploadUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"PublishUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Attachments\" /v \"SaveZoneInformation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Diagnostics\\Performance\" /v \"DisablediagnosticTracing\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WDI\\{9c5a40da-b965-4fc3-8781-88dd50a6299d}\" /v \"ScenarioExecutionEnabled\" /t REG_DWORD /d \"0\" /f\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\" /Disable\n%windir%\\system32\\SystemPropertiesPerformance.exe",
      "sha256": "c8270e784b85e0809f26d0f4e3e43bdafd5bcfe2e7797b74867936fb9e355496"
    },
    {
      "id": "c1",
      "category": "clean",
      "title": "إزالة الأجهزة غير المتصلة",
      "description": "يحذف أجهزة PnP ذات الحالة Unknown؛ هذا الخيار لا يحذف الملفات المؤقتة.",
      "risk": "high",
      "warnings": [
        "يحذف تسجيل الأجهزة ذات الحالة Unknown باستخدام pnputil."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1812,
          1830
        ]
      ],
      "commands": "POWERSHELL \"$Devices = Get-PnpDevice | ? Status -eq Unknown;foreach ($Device in $Devices) { &\\\"pnputil\\\" /remove-device $Device.InstanceId }\"",
      "sha256": "f2223bdda341ce4d3a3864a78c1186e2a9562a889406a70b9e5840c5d399f360"
    },
    {
      "id": "c2",
      "category": "clean",
      "title": "فتح تنظيف القرص",
      "description": "فتح أداة Windows لاختيار الملفات التي تريد تنظيفها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          1831,
          1845
        ]
      ],
      "commands": "start cleanmgr.exe",
      "sha256": "eae185ca0274b71bae1d28af0475f121025a3c57dbb1dc2e338456c7c4fb3ef3"
    },
    {
      "id": "4gb",
      "category": "memory",
      "title": "إعداد ذاكرة 4 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1951,
          1964
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Enable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"4194304\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"0\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "c325d4b157868f7702223d9a82a6f86e7fcc69eef54c1d0a03a99e6016b32830"
    },
    {
      "id": "8gb",
      "category": "memory",
      "title": "إعداد ذاكرة 8 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1965,
          1978
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Enable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"8388608\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"0\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "0d3a145f7aac23dad87ac285731b468d5f092392e53f263aa2eaa5c1c734ebc0"
    },
    {
      "id": "12gb",
      "category": "memory",
      "title": "إعداد ذاكرة 12 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1979,
          1992
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Enable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"12582912\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"0\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "ee35eb40a2608b5ca283998f81ae375db62e913b78d2e115ef0d27ebe3eade95"
    },
    {
      "id": "16gb",
      "category": "memory",
      "title": "إعداد ذاكرة 16 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1993,
          2007
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"16777216\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"1\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "e78d07af67dd31167e3dfc4ce11e496fd4bdbd188e0d954545da77420bc3d1bd"
    },
    {
      "id": "24gb",
      "category": "memory",
      "title": "إعداد ذاكرة 24 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2008,
          2021
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"25165824\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"1\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "bf9d7e8b5c2d8a9cda7726f13d1163995d7342d53f4f66d1ace89299e1b4662c"
    },
    {
      "id": "32gb",
      "category": "memory",
      "title": "إعداد ذاكرة 32 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2022,
          2035
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"33554432\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"1\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "9b4d1ae355bd7bf861199be86a8c834a681787b42ddee14d8d1dcb7f3f5426b7"
    },
    {
      "id": "48gb",
      "category": "memory",
      "title": "إعداد ذاكرة 48 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2036,
          2049
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"50331648\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"1\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "e39919d911451d55e1d9bc6a9ea888151e3d39da669588e060623991aa384350"
    },
    {
      "id": "64gb",
      "category": "memory",
      "title": "إعداد ذاكرة 64 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2050,
          2063
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"67108864\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"1\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "c083c34ebc9ee1fc5d3ae22f2353e3e4c69b5537b316ea6c0d9f6af8dd98c82a"
    },
    {
      "id": "128gb",
      "category": "memory",
      "title": "إعداد ذاكرة 128 GB",
      "description": "قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2064,
          2077
        ],
        [
          2078,
          2122
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"134217728\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"1\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Disable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"ClearPageFileAtShutdown\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"NonPagedPoolSize\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolQuota\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PagedPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SecondLevelDataCache\" /t REG_DWORD /d \"1024\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionPoolSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SessionViewSize\" /t REG_DWORD /d \"192\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"SystemPages\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PhysicalAddressExtension\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"PoolUsageMaximum\" /t REG_DWORD /d \"96\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "fad7a1db6e851dd02bb4f5956e01bb185234488cbbd2b786a7b820a214bc43a8"
    },
    {
      "id": "gpunvidia",
      "category": "gpu",
      "title": "تعديلات NVIDIA",
      "description": "اختر الشركة المطابقة لكرت الشاشة؛ لا يوجد تراجع مخصص لهذا القسم في الأصل.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          2172,
          2290
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"PreferSystemMemoryContiguous\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"DisableWriteCombining\" /t REG_DWORD /d \"1\" /f\nfor /f %%i in ('wmic path Win32_VideoController get PNPDeviceID') do set \"str=%%i\" (\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\Affinity Policy\" /v \"DevicePriority\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties\" /v \"MessageNumberLimit\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties\" /v \"MSISupported\" /t REG_DWORD /d \"1\" /f\n)\nfor /f %%m in ('wmic path Win32_VideoController get PNPDeviceID^| findstr /L \"PCI\\VEN_\"') do (\nfor /f \"tokens=3\" %%a in ('Reg.exe query \"HKLM\\SYSTEM\\ControlSet001\\Enum\\%%m\" /v \"Driver\"') do (\nfor /f %%m in ('echo %w%- %%a ^| findstr \"{\"') do (\nReg.exe add \"HKLM\\System\\ControlSet001\\Control\\Class\\%%m\" /v \"RMHdcpKeyglobZero\" /t REG_DWORD /d \"1\" /f\n)\n)\n)\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"DisablePreemption\" /t Reg_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"DisableCudaContextPreemption\" /t Reg_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"GPUPreemptionLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"ComputePreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableMidGfxPreemptionVGPU\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableMidBufferPreemptionForHighTdrTimeout\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableAsyncMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableSCGMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"PerfAnalyzeMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableMidGfxPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnableCEPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisableCudaContextPreemption\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisablePreemptionOnS3S4\" /t REG_DWORD /d \"1\" /f\nfsutil behavior query memoryusage\nfsutil behavior set memoryusage 2\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"D3PCLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"F1TransitionLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"LOWLATENCY\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"Node3DLowLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"PciLatencyTimerControl\" /t REG_DWORD /d \"20\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RMDeepL1EntryLatencyUsec\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RmGspcMaxFtuS\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RmGspcMinFtuS\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RmGspcPerioduS\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RMLpwrEiIdleThresholdUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RMLpwrGrIdleThresholdUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RMLpwrGrRgIdleThresholdUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"RMLpwrMsIdleThresholdUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"VRDirectFlipDPCDelayUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"VRDirectFlipTimingMarginUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"VRDirectJITFlipMsHybridFlipDelayUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"vrrCursorMarginUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"vrrDeflickerMarginUs\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"vrrDeflickerMaxUs\" /t REG_DWORD /d \"1\" /f\nreg delete \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\" /v \"NvBackend\" /f\nReg.exe add \"HKLM\\SOFTWARE\\NVIDIA Corporation\\Global\\FTS\" /v \"EnableRID66610\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\NVIDIA Corporation\\Global\\FTS\" /v \"EnableRID64640\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\NVIDIA Corporation\\Global\\FTS\" /v \"EnableRID44231\" /t REG_DWORD /d \"0\" /f\nschtasks /change /Disable /tn \"NvTmRep_CrashReport1_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nschtasks /change /Disable /tn \"NvTmRep_CrashReport2_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nschtasks /change /Disable /tn \"NvTmRep_CrashReport3_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nschtasks /change /Disable /tn \"NvTmRep_CrashReport4_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nschtasks /change /Disable /tn \"NvDriverUpdateCheckDaily_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nschtasks /change /Disable /tn \"NVIDIA GeForce Experience SelfUpdate_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nschtasks /change /Disable /tn \"NvTmMon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\GpuEnergyDrv\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\GpuEnergyDr\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"DisablePreemption\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"DisableCudaContextPreemption\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"EnableCEPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"DisablePreemptionOnS3S4\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\" /v \"ComputePreemption\" /t REG_DWORD /d \"0\" /f",
      "sha256": "38873f460b8abb59c72dd4dc070a0dca620d86df4d801cf551f2978299721851"
    },
    {
      "id": "gpuamd",
      "category": "gpu",
      "title": "تعديلات AMD Radeon",
      "description": "اختر الشركة المطابقة لكرت الشاشة؛ لا يوجد تراجع مخصص لهذا القسم في الأصل.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          2291,
          2542
        ]
      ],
      "commands": "for /f %%i in ('wmic path Win32_VideoController get PNPDeviceID') do set \"str=%%i\" (\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\Affinity Policy\" /v \"DevicePriority\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties\" /v \"MessageNumberLimit\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties\" /v \"MSISupported\" /t REG_DWORD /d \"1\" /f\n)\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\GpuEnergyDrv\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\GpuEnergyDr\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\\\\DAL2_DATA__2_0\\DisplayPath_4\\EDID_D109_78E9\\Option\" /v \"ProtectionControl\" /t REG_BINARY /d \"0100000001000000\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"3D_Refresh_Rate_Override_DEF\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AllowSnapshot\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AAF_NA\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AntiAlias_NA\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"ASTT_NA\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AllowSubscription\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AreaAniso_NA\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AllowRSOverlay\" /t REG_SZ /d \"false\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"Adaptive De-interlacing\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AllowSkins\" /t REG_SZ /d \"false\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"AutoColorDepthReduction_NA\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisableSAMUPowerGating\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisableUVDPowerGatingDynamic\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisableVCEPowerGating\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisablePowerGating\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisabledrmdmaPowerGating\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnablingVceSwClockGating\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnablingUvdClockGating\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnablingAspmL0s\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnablingAspmL1\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnablingUlps\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"EnablingUlps_NA\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"KMD_DeLagEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"KMD_FRTEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisabledMACopy\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"DisableBlockWrite\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"StutterMode\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"PP_SclkDeepSleepDisable\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"PP_ThermalAutoThrottlingEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"KMD_EnableComputePreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\\UMD\" /v \"Main3D_DEF\" /t REG_SZ /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\\UMD\" /v \"Main3D\" /t REG_BINARY /d \"3100\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\\UMD\" /v \"FlipQueueSize\" /t REG_BINARY /d \"3100\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\\UMD\" /v \"ShaderCache\" /t REG_BINARY /d \"3200\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\\UMD\" /v \"TFQ\" /t REG_BINARY /d \"3200\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnablePreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"GPUPreemptionLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableAsyncMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableMidGfxPreemptionVGPU\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableMidBufferPreemptionForHighTdrTimeout\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableSCGMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"PerfAnalyzeMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableMidGfxPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableMidBufferPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"EnableCEPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"DisableCudaContextPreemption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"DisablePreemptionOnS3S4\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"ComputePreemptionLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler\" /v \"DisablePreemption\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000\" /v \"PP_GPUPowerDownEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\amdlog\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatencyCheckEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"Latency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceDefault\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceFSVP\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyTolerancePerfOverride\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceScreenOffIR\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceVSyncEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"RtlCapabilityCheckLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"QosManagesIdleProcessors\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DisableVsyncLatencyUpdate\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DisableSensorWatchdog\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"CoalescingTimerInterval\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"InterruptSteeringDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LowLatencyScalingPercentage\" /t REG_DWORD /d \"100\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"HighPerformance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"HighestPerformance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MinimumThrottlePercent\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MaximumThrottlePercent\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MaximumPerformancePercent\" /t REG_DWORD /d \"100\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"InitialUnparkCount\" /t REG_DWORD /d \"100\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyActivelyUsed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleLongTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleShortTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleVeryLongTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle0\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle0MonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle1\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle1MonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceMemory\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceNoContextMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceOther\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceTimerPeriod\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceActivelyUsed\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"Latency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MiracastPerfTrackGraphicsLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MonitorLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MonitorRefreshLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"TransitionLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DisableVsyncLatencyUpdate\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DisableSensorWatchdog\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"InterruptSteeringDisabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatencyCheckEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"Latency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceDefault\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceFSVP\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyTolerancePerfOverride\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceScreenOffIR\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceVSyncEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"RtlCapabilityCheckLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LowLatencyScalingPercentage\" /t REG_DWORD /d \"100\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MaxIAverageGraphicsLatencyInOneBucket\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyActivelyUsed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleLongTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleShortTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultD3TransitionLatencyIdleVeryLongTime\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle0\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle0MonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle1\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceIdle1MonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceMemory\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceNoContextMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceOther\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultLatencyToleranceTimerPeriod\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceActivelyUsed\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceMonitorOff\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceNoContext\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MaxIAverageGraphicsLatencyInOneBucket\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"Latency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MiracastPerfTrackGraphicsLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MonitorLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"MonitorRefreshLatencyTolerance\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"TransitionLatency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"MonitorLatencyTolerance\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"MonitorRefreshLatencyTolerance\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MonitorLatencyTolerance\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MonitorRefreshLatencyTolerance\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"RMDisablePostL2Compression\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"RmDisableRegistryCaching\" /t REG_DWORD /d \"1\" /f\nfsutil behavior query memoryusage\nfsutil behavior set memoryusage 2",
      "sha256": "e73c1b0192859cb7272dac9d9bfb10b1488614fa2a52f99132ce738a6e4e2110"
    },
    {
      "id": "gpuintel",
      "category": "gpu",
      "title": "تعديلات Intel Graphics",
      "description": "اختر الشركة المطابقة لكرت الشاشة؛ لا يوجد تراجع مخصص لهذا القسم في الأصل.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          2543,
          2581
        ]
      ],
      "commands": "for /f %%t in ('Reg query \"HKLM\\System\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\" /t REG_SZ /s /e /f \"Intel\" ^| findstr \"HKEY\"') do (\nReg.exe add \"%%t\" /v \"Disabling_OverlayDSQualityEnhancement\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"%%t\" /v \"IncreaseFixedSegment\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"%%t\" /v \"AdaptiveVsyncEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"%%t\" /v \"DisablingPFonDP\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"%%t\" /v \"EnableCompensationForDVI\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"%%t\" /v \"NoFastLinkTrainingForeDP\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"%%t\" /v \"ACPowerPolicyVersion\" /t REG_DWORD /d \"16898\" /f\nReg.exe add \"%%t\" /v \"DCPowerPolicyVersion\" /t REG_DWORD /d \"16642\" /f\n)\nReg.exe add \"HKLM\\Software\\Intel\\GMM\" /v \"DedicatedSegmentSize\" /t REG_DWORD /d \"512\" /f",
      "sha256": "2a1b5734b65a5eca1590421d70811bed5869e4d764a9accd63bbd404d3b7ed68"
    },
    {
      "id": "cpuintel",
      "category": "cpu",
      "title": "تعديلات معالج Intel",
      "description": "يغيّر سياسات المعالج والطاقة والإقلاع، وقد يزيد الحرارة واستهلاك الطاقة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "قد ترتفع الحرارة ويزيد استهلاك الطاقة؛ لا تستخدمه لمعالجة جهاز يعاني من الحرارة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2710,
          2785
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet002\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet002\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f\nReg.exe add HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power /v CoreParkingDisabled /t REG_DWORD /d 0 /f\npowercfg -setacvalueindex scheme_current sub_processor CPMINCORES 100\npowercfg /setactive SCHEME_CURRENT\nbcdedit /set allowedinmemorysettings 0x0\nbcdedit /set isolatedcontext No\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DistributeTimers\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DisableTsx\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"EventProcessorEnabled\" /t REG_DWORD /d \"0\" /f\npowercfg /setACvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 1\npowercfg /setDCvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 1\npowercfg /setactive SCHEME_CURRENT\nset THREADS=%NUMBER_OF_PROCESSORS% & bcdedit /set {current} numproc %NUMBER_OF_PROCESSORS%\npowercfg -setacvalueindex scheme_current SUB_SLEEP AWAYMODE 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current SUB_SLEEP ALLOWSTANDBY 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current SUB_SLEEP HYBRIDSLEEP 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor PROCTHROTTLEMIN 100\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor IDLESCALING 1\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor THROTTLING 0\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f",
      "sha256": "bacea3e77f4d1d7a4a3b7abb6d97a4ffc80eef33fa361ac6ef07f204ba8b5830"
    },
    {
      "id": "cpuamd",
      "category": "cpu",
      "title": "تعديلات معالج AMD",
      "description": "يغيّر سياسات المعالج والطاقة والإقلاع، وقد يزيد الحرارة واستهلاك الطاقة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "قد ترتفع الحرارة ويزيد استهلاك الطاقة؛ لا تستخدمه لمعالجة جهاز يعاني من الحرارة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2786,
          2856
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet002\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet002\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f\nReg.exe add HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power /v CoreParkingDisabled /t REG_DWORD /d 0 /f\npowercfg -setacvalueindex scheme_current sub_processor CPMINCORES 100\npowercfg /setactive SCHEME_CURRENT\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DistributeTimers\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DisableTsx\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"EventProcessorEnabled\" /t REG_DWORD /d \"0\" /f\npowercfg /setACvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 1\npowercfg /setDCvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 1\npowercfg /setactive SCHEME_CURRENT\nset THREADS=%NUMBER_OF_PROCESSORS% & bcdedit /set {current} numproc %NUMBER_OF_PROCESSORS%\npowercfg -setacvalueindex scheme_current SUB_SLEEP AWAYMODE 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current SUB_SLEEP ALLOWSTANDBY 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current SUB_SLEEP HYBRIDSLEEP 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor PROCTHROTTLEMIN 100\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor IDLESCALING 1\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor THROTTLING 0\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"0\" /f",
      "sha256": "1811195b79b9afe4d7103566123683684402846c8721adbea0a680f19df92ff5"
    },
    {
      "id": "usb",
      "category": "usb",
      "title": "تعديل إدارة طاقة USB",
      "description": "تعديلات توفير الطاقة لأجهزة ومنافذ USB.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          2857,
          2897
        ]
      ],
      "commands": "for /f %%i in ('wmic path Win32_USBController get PNPDeviceID^| findstr /l \"PCI\\VEN_\"') do (\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"AllowIdleIrpInD3\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"D3ColdSupported\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"DeviceSelectiveSuspended\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"EnableSelectiveSuspend\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"EnhancedPowerManagementEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"SelectiveSuspendEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"SelectiveSuspendOn\" /t REG_DWORD /d \"0\" /f\n)\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\usbxhci\\Parameters\" /v \"ThreadPriority\" /t REG_DWORD /d \"31\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\USBHUB3\\Parameters\" /v \"ThreadPriority\" /t REG_DWORD /d \"31\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\\Parameters\" /v \"ThreadPriority\" /t REG_DWORD /d \"31\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\NDIS\\Parameters\" /v \"ThreadPriority\" /t REG_DWORD /d \"31\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\USB\" /v \"DisableSelectiveSuspend\" /t REG_DWORD /d \"1\" /f\nfor /f %%i in ('wmic path Win32_USBController get PNPDeviceID') do set \"str=%%i\" & (\nReg.exe delete \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\Affinity Policy\" /v \"DevicePriority\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties\" /v \"MSISupported\" /t REG_DWORD /d \"1\" /f\n)",
      "sha256": "3571f4a8d1a7fe3d6299a6493d5bbfaa06cfea549d3c2ded7f4c135ca152ef4e"
    },
    {
      "id": "power1",
      "category": "power",
      "title": "استيراد خطة Aziz للطاقة",
      "description": "يتطلب الملف C:\\AzizTools\\PowerPlan_GUID.pow؛ يفتح خيارات الطاقة لاختيار الخطة.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [
        "C:\\AzizTools\\PowerPlan_GUID.pow"
      ],
      "source": [
        [
          4141,
          4158
        ]
      ],
      "commands": "powercfg -import C:\\AzizTools\\PowerPlan_GUID.pow\npowercfg.cpl",
      "sha256": "6e6602b18f3297db4bc79dd95cfe65fdbce3fa3578c585d7fe2773305596c1da"
    },
    {
      "id": "power2",
      "category": "power",
      "title": "تعطيل تسجيل بيانات الطاقة",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          4159,
          4174
        ]
      ],
      "commands": "Reg add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\TaggedEnergy\" /v \"DisableTaggedEnergyLogging\" /t REG_DWORD /d \"1\" /f\nReg add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\TaggedEnergy\" /v \"TelemetryMaxApplication\" /t REG_DWORD /d \"0\" /f\nReg add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\TaggedEnergy\" /v \"TelemetryMaxTagPerApplication\" /t REG_DWORD /d \"0\" /f",
      "sha256": "8df04552f0c41a7d949637c0bdb39d3f823aa2995e7107078674d3c3079299ac"
    },
    {
      "id": "powerc",
      "category": "power",
      "title": "فتح خيارات الطاقة",
      "description": "يفتح لوحة تحكم الطاقة فقط، ولا يعطّل خدمات Xbox.",
      "risk": "standard",
      "warnings": [],
      "notes": "أُوقِف السقوط غير المقصود إلى قسم startapps بعد فتح لوحة الطاقة.",
      "requires": [],
      "source": [
        [
          4175,
          4177
        ]
      ],
      "commands": "control /name Microsoft.PowerOptions",
      "sha256": "b7482276c74b4a541036f5fe74839c14254b88ea2e8f0418baa31e148f2794a2"
    },
    {
      "id": "d1",
      "category": "debloat",
      "title": "تعطيل Game DVR",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          3009,
          3031
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\Software\\Microsoft\\GameBar\" /v \"UseNexusForGameBarEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\GameBar\" /v \"GameDVR_Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"AppCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"AudioCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"CursorCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"HistoricalCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\System\\GameConfigStore\" /v \"GameDVR_Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\GameDVR\" /v \"AllowgameDVR\" /t REG_DWORD /d \"0\" /f",
      "sha256": "24bf229649d41c909c4a48f73ff01d67d8a1f36971717b24cca667283a06f5ff"
    },
    {
      "id": "d2",
      "category": "debloat",
      "title": "تعطيل Telemetry",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3032,
          3163
        ]
      ],
      "commands": "schtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\AitAgent\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\AitAgent\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Windows Error Reporting\\QueueReporting\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Windows Error Reporting\\QueueReporting\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\CloudExperienceHost\\CreateObjectTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\CloudExperienceHost\\CreateObjectTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskFootprint\\Diagnostics\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskFootprint\\Diagnostics\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\"\nschtasks /change /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\"\nschtasks /change /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\AppID\\SmartScreenSpecific\"\nschtasks /change /tn \"\\Microsoft\\Windows\\AppID\\SmartScreenSpecific\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\"\nschtasks /change /TN \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\" /Disable\nschtasks /end /tn \"\\Microsoftd\\Office\\OfficeTelemetryAgentFallBack\"\nschtasks /change /TN \"\\Microsoftd\\Office\\OfficeTelemetryAgentFallBack\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\"\nschtasks /change /TN \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Time Synchronization\\ForceSynchronizeTime\"\nschtasks /change /TN \"\\Microsoft\\Windows\\Time Synchronization\\ForceSynchronizeTime\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Time Synchronization\\SynchronizeTime\"\nschtasks /change /TN \"\\Microsoft\\Windows\\Time Synchronization\\SynchronizeTime\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\WindowsUpdate\\Automatic App Update\"\nschtasks /change /TN \"\\Microsoft\\Windows\\WindowsUpdate\\Automatic App Update\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Device Information\\Device\"\nschtasks /change /TN \"\\Microsoft\\Windows\\Device Information\\Device\" /Disable\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata\" /v \"PreventDeviceMetadataFromNetwork\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection\" /v \"AllowTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitInkCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitTextCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Sensor\\Permissions\\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}\" /v \"SensorPermissionState\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Sensor\\Overrides\\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}\" /v \"SensorPermissionState\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"AllowTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"DoNotShowFeedbackNotifications\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"AllowCommercialDataPipeline\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"AllowDeviceNameInTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"LimitEnhancedDiagnosticDataWindowsAnalytics\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"MicrosoftEdgeDataOptIn\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Siuf\\Rules\" /v \"NumberOfSIUFInPeriod\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Siuf\\Rules\" /v \"PeriodInNanoSeconds\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Policies\\Microsoft\\Assistance\\Client\\1.0\" /v \"NoExplicitFeedback\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Assistance\\Client\\1.0\" /v \"NoActiveHelp\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat\" /v \"DisableInventory\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat\" /v \"AITEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat\" /v \"DisableUAR\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC\" /v \"PreventHandwritingDataSharing\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC\" /v \"DoSvc\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableLocation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableLocationScripting\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableSensors\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableWindowsLocationProvider\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"PublishUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnableActivityFeed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"UploadUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows\" /v \"CEIPEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Reliability\" /v \"CEIPEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Reliability\" /v \"SqmLoggerRunning\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Windows\" /v \"CEIPEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Windows\" /v \"DisableOptinExperience\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Windows\" /v \"SqmLoggerRunning\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\IE\" /v \"SqmLoggerRunning\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\HandwritingErrorReports\" /v \"PreventHandwritingErrorReports\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\MediaPlayer\\Preferences\" /v \"UsageTracking\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableSoftLanding\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Peernet\" /v \"Disabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DeliveryOptimization\\Config\" /v DODownloadMode /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\default\\WiFi\\AllowWiFiHotSpotReporting\" /v value /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\InputPersonalization\\TrainedDataStore\" /v \"HarvestContacts\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AdvertisingInfo\" /v \"DisabledByGroupPolicy\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\MRT\" /v \"DontOfferThroughWUAU\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Biometrics\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKCU\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f",
      "sha256": "a30bd11f7a4c387c0491303a1c83936cf4ad537ab36bc4bf00b28645b1e3dc78"
    },
    {
      "id": "d3",
      "category": "debloat",
      "title": "تعطيل خدمات Xbox",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          3164,
          3183
        ]
      ],
      "commands": "sc config xbgm start= Disabled\nsc config XblAuthManager start= Disabled\nsc config XblGameSave start= Disabled\nsc config XboxGipSvc start= Disabled\nsc config XboxNetApiSvc start= Disabled",
      "sha256": "3fcdb10344f379609441f0d004470f7e6c22fd6293552733eeb678b491c0aacb"
    },
    {
      "id": "d4",
      "category": "debloat",
      "title": "تعطيل Hyper-V",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "قد يعطّل Hyper-V والأجهزة الافتراضية وميزات تعتمد عليه."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3184,
          3206
        ]
      ],
      "commands": "Reg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\HvHost\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmickvpexchange\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicguestinterface\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicshutdown\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicheartbeat\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicvmsession\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicrdv\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmictimesync\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicvss\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "4080b0c5814d720e44aeecbce6b87948ee27d4f6a430537a6b28d00c9dd32405"
    },
    {
      "id": "d5",
      "category": "debloat",
      "title": "تعطيل بيانات Office",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          3207,
          3251
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\Software\\Microsoft\\Office\\Common\\ClientTelemetry\" /v \"DisableTelemetry\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"sendcustomerdata\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\Feedback\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\Feedback\" /v \"includescreenshot\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Outlook\\Options\\Mail\" /v \"EnableLogging\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Word\\Options\" /v \"EnableLogging\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\Common\\ClientTelemetry\" /v \"SendTelemetry\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"qmEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"updatereliabilitydata\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\General\" /v \"shownfirstrunoptin\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\General\" /v \"skydrivesigninoption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\ptwatson\" /v \"ptwoptin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Firstrun\" /v \"Disablemovie\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"Enablelogging\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"EnableUpload\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"EnableFileObfuscation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"accesssolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"olksolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"onenotesolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"pptsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"projectsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"publishersolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"visiosolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"wdsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"xlsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"agave\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"appaddins\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"comaddins\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"documentfiles\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"templatefiles\" /t REG_DWORD /d \"1\" /f",
      "sha256": "8b09674fa692b83f7b82bc84345e2e4776343e9e503337523ca3f0e35c652c71"
    },
    {
      "id": "d6",
      "category": "debloat",
      "title": "تعطيل الطباعة والخرائط",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "يتضمن تعطيل الطباعة وخدمات أخرى قد تستخدمها."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3252,
          3269
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\Spooler\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\PrintNotify\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\MapsBroker\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "307221d852ced6d62a2d9c597fb3a59f88e3bd7ecc6b1321798ba20605f2b26e"
    },
    {
      "id": "d7",
      "category": "debloat",
      "title": "إزالة Cortana",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          3270,
          3298
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortana\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCloudSearch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortanaAboveLock\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DisablegWebSearch\" /t REG_DWORD /d \"0\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Get-appxpackage -allusers *Microsoft.549981C3F5F10* | Remove-AppxPackage\"",
      "sha256": "f29cdade1a773e41f0598a629d7362a061e3413c8948b297894e470c0c2f8e4d"
    },
    {
      "id": "d12",
      "category": "debloat",
      "title": "تعطيل البصمة والتعرف الحيوي",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "قد يؤثر في تسجيل الدخول بالبصمة وWindows Hello."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3299,
          3314
        ]
      ],
      "commands": "reg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Biometrics\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nreg add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\WbioSrvc\" /v \"Start\" /t REG_DWORD /d \"4\" /f",
      "sha256": "89a7f301dab4d9c14d02bbf3794211c0ea4b16d2ba50046d87466cf21c9dbb63"
    },
    {
      "id": "d9",
      "category": "debloat",
      "title": "تعطيل Autologgers",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          3352,
          3405
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\AppModel\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Cellcore\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Circular Kernel Context Logger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\CloudExperienceHostOobe\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DataMarket\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DefenderApiLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DefenderAuditLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DiagLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\HolographicDevice\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\iclsClient\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\iclsProxy\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\LwtNetLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Mellanox-Kernel\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Microsoft-Windows-AssignedAccess-Trace\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Microsoft-Windows-Setup\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\NBSMBLOGGER\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\PEAuthLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\RdrLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\ReadyBoot\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SetupPlatform\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SetupPlatformTel\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SocketHeciServer\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SpoolerLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SQMLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TCPIPLOGGER\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TileStore\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Tpm\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TPMProvisioningService\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\UBPM\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WdiContextLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WFP-IPsec Trace\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiDriverIHVSession\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiDriverIHVSessionRepro\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiSession\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WinPhoneCritical\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogEnabling\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableThirdPartySuggestions\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableWindowsConsumerFeatures\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\Credssp\" /v \"DebugLogLevel\" /t REG_DWORD /d \"0\" /f",
      "sha256": "6a5a4f209a9a628522e89677c816c92ba5d9f563cdd0bbf15d0f7227e081cd67"
    },
    {
      "id": "d10",
      "category": "debloat",
      "title": "تعطيل برنامج تجربة العملاء",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          3315,
          3351
        ]
      ],
      "commands": "schtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\"\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\"",
      "sha256": "0a73b9a2d8cf3e82a541fd31d4665c492e2b3c90c44ddbfb95b6a6d9a6d6b753"
    },
    {
      "id": "alldebloat",
      "category": "debloat",
      "title": "تطبيق مجموعة إزالة الخدمات",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "يتضمن تعطيل الطباعة وخدمات أخرى قد تستخدمها.",
        "قد يعطّل Hyper-V والأجهزة الافتراضية وميزات تعتمد عليه."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3406,
          3703
        ]
      ],
      "commands": "schtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\AitAgent\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\AitAgent\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Windows Error Reporting\\QueueReporting\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Windows Error Reporting\\QueueReporting\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\CloudExperienceHost\\CreateObjectTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\CloudExperienceHost\\CreateObjectTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskFootprint\\Diagnostics\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskFootprint\\Diagnostics\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\"\nschtasks /change /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\"\nschtasks /change /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\AppID\\SmartScreenSpecific\"\nschtasks /change /tn \"\\Microsoft\\Windows\\AppID\\SmartScreenSpecific\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\"\nschtasks /change /TN \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\" /Disable\nschtasks /end /tn \"\\Microsoftd\\Office\\OfficeTelemetryAgentFallBack\"\nschtasks /change /TN \"\\Microsoftd\\Office\\OfficeTelemetryAgentFallBack\" /Disable\nschtasks /end /tn \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\"\nschtasks /change /TN \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Time Synchronization\\ForceSynchronizeTime\"\nschtasks /change /TN \"\\Microsoft\\Windows\\Time Synchronization\\ForceSynchronizeTime\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Time Synchronization\\SynchronizeTime\"\nschtasks /change /TN \"\\Microsoft\\Windows\\Time Synchronization\\SynchronizeTime\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\WindowsUpdate\\Automatic App Update\"\nschtasks /change /TN \"\\Microsoft\\Windows\\WindowsUpdate\\Automatic App Update\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Device Information\\Device\"\nschtasks /change /TN \"\\Microsoft\\Windows\\Device Information\\Device\" /Disable\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata\" /v \"PreventDeviceMetadataFromNetwork\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection\" /v \"AllowTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitInkCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitTextCollection\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Sensor\\Permissions\\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}\" /v \"SensorPermissionState\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Sensor\\Overrides\\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}\" /v \"SensorPermissionState\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"AllowTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"DoNotShowFeedbackNotifications\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"AllowCommercialDataPipeline\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"AllowDeviceNameInTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"LimitEnhancedDiagnosticDataWindowsAnalytics\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection\" /v \"MicrosoftEdgeDataOptIn\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Siuf\\Rules\" /v \"NumberOfSIUFInPeriod\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Siuf\\Rules\" /v \"PeriodInNanoSeconds\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Policies\\Microsoft\\Assistance\\Client\\1.0\" /v \"NoExplicitFeedback\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Assistance\\Client\\1.0\" /v \"NoActiveHelp\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat\" /v \"DisableInventory\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat\" /v \"AITEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat\" /v \"DisableUAR\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC\" /v \"PreventHandwritingDataSharing\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC\" /v \"DoSvc\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableLocation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableLocationScripting\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableSensors\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors\" /v \"DisableWindowsLocationProvider\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"PublishUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnableActivityFeed\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"UploadUserActivities\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows\" /v \"CEIPEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Reliability\" /v \"CEIPEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Reliability\" /v \"SqmLoggerRunning\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Windows\" /v \"CEIPEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Windows\" /v \"DisableOptinExperience\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\Windows\" /v \"SqmLoggerRunning\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\SQMClient\\IE\" /v \"SqmLoggerRunning\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\HandwritingErrorReports\" /v \"PreventHandwritingErrorReports\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\MediaPlayer\\Preferences\" /v \"UsageTracking\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableSoftLanding\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Peernet\" /v \"Disabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DeliveryOptimization\\Config\" /v DODownloadMode /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\default\\WiFi\\AllowWiFiHotSpotReporting\" /v value /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\InputPersonalization\\TrainedDataStore\" /v \"HarvestContacts\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AdvertisingInfo\" /v \"DisabledByGroupPolicy\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\MRT\" /v \"DontOfferThroughWUAU\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Biometrics\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKCU\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\AppModel\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Cellcore\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Circular Kernel Context Logger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\CloudExperienceHostOobe\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DataMarket\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DefenderApiLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DefenderAuditLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DiagLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\HolographicDevice\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\iclsClient\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\iclsProxy\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\LwtNetLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Mellanox-Kernel\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Microsoft-Windows-AssignedAccess-Trace\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Microsoft-Windows-Setup\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\NBSMBLOGGER\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\PEAuthLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\RdrLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\ReadyBoot\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SetupPlatform\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SetupPlatformTel\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SocketHeciServer\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SpoolerLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SQMLogger\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TCPIPLOGGER\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TileStore\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Tpm\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TPMProvisioningService\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\UBPM\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WdiContextLog\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WFP-IPsec Trace\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiDriverIHVSession\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiDriverIHVSessionRepro\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiSession\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WinPhoneCritical\" /v \"Start\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogEnabling\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableThirdPartySuggestions\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableWindowsConsumerFeatures\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\Credssp\" /v \"DebugLogLevel\" /t REG_DWORD /d \"0\" /f\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\"\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\" /Disable\nschtasks /end /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\Spooler\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\PrintNotify\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\MapsBroker\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\Common\\ClientTelemetry\" /v \"DisableTelemetry\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"sendcustomerdata\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\Feedback\" /v \"Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\Feedback\" /v \"includescreenshot\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Outlook\\Options\\Mail\" /v \"EnableLogging\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Word\\Options\" /v \"EnableLogging\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\Common\\ClientTelemetry\" /v \"SendTelemetry\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"qmEnable\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"updatereliabilitydata\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\General\" /v \"shownfirstrunoptin\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\General\" /v \"skydrivesigninoption\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\ptwatson\" /v \"ptwoptin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Firstrun\" /v \"Disablemovie\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"Enablelogging\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"EnableUpload\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"EnableFileObfuscation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"accesssolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"olksolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"onenotesolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"pptsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"projectsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"publishersolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"visiosolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"wdsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"xlsolution\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"agave\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"appaddins\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"comaddins\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"documentfiles\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"templatefiles\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\GameBar\" /v \"UseNexusForGameBarEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\GameBar\" /v \"GameDVR_Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"AppCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"AudioCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"CursorCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"HistoricalCaptureEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\System\\GameConfigStore\" /v \"GameDVR_Enabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\GameDVR\" /v \"AllowgameDVR\" /t REG_DWORD /d \"0\" /f\nsc config xbgm start= Disabled\nsc config XblAuthManager start= Disabled\nsc config XblGameSave start= Disabled\nsc config XboxGipSvc start= Disabled\nsc config XboxNetApiSvc start= Disabled\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortana\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCloudSearch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortanaAboveLock\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DisableWebSearch\" /t REG_DWORD /d \"0\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Get-appxpackage -allusers *Microsoft.549981C3F5F10* | Remove-AppxPackage\"\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\HvHost\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmickvpexchange\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicguestinterface\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicshutdown\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicheartbeat\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicvmsession\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicrdv\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmictimesync\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicvss\" /v \"Start\" /t REG_DWORD /d \"4\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard\" /v \"EnablingVirtualizationBasedSecurity\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard\" /v \"HVCIMATRequired\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DisableExceptionChainValidation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"KernelSEHOPEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"EnablingCfg\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\" /v \"ProtectionMode\" /t REG_DWORD /d \"0\" /f\nif \"%ProcessorManufacturer%\" EQU \"AuthenticAMD\" (\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"2\" /f\n) else (\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /t REG_DWORD /d \"3\" /f\n)\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"MoveImages\" /t REG_DWORD /d \"0\" /f",
      "sha256": "a4bdb1f8750bb6899e5467b26e4e616d53911419180e0e702ae42d0d2146833a"
    },
    {
      "id": "storage",
      "category": "storage",
      "title": "تعديل التخزين وذاكرة الكتابة",
      "description": "يغيّر سياسة التخزين المؤقت ويفترض حماية ذاكرة القرص من انقطاع الكهرباء؛ قد يسبب فقد بيانات إذا لم تكن الحماية موجودة.",
      "risk": "high",
      "warnings": [
        "تغيير حماية ذاكرة الكتابة قد يؤدي إلى فقد البيانات عند انقطاع الطاقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3918,
          3953
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdleExitEnergyMicroJoules\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdleExitLatencyMs\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdlePowerMw\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdleTimeLengthMs\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdleExitEnergyMicroJoules\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdleExitLatencyMs\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdlePowerMw\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdleTimeLengthMs\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdleExitEnergyMicroJoules\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdleExitLatencyMs\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdlePowerMw\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdleTimeLengthMs\" /t REG_DWORD /d \"4294967295\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdleExitEnergyMicroJoules\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdleExitLatencyMs\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdlePowerMw\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdleTimeLengthMs\" /t REG_DWORD /d \"4294967295\" /f\nFor /f \"Delims=\" %%k in ('Reg.exe Query HKLM\\SYSTEM\\CurrentControlSet\\Enum /f \"{4d36e967-e325-11ce-bfc1-08002be10318}\" /d /s^|Find \"HKEY\"') do (\nReg.exe add \"%%k\\Device Parameters\\Disk\" /v UserWriteCacheSetting /t REG_DWORD /d 1 /f\nReg.exe add \"%%k\\Device Parameters\\Disk\" /v CacheIsPowerProtected /t REG_DWORD /d 1 /f\n)",
      "sha256": "afc12154fca843f7c35e6aa541ca88ef96dc5365b06d5afbf83bf5dc58737045"
    },
    {
      "id": "fixfiles",
      "category": "repair",
      "title": "فحص وإصلاح Windows",
      "description": "تشغيل أوامر DISM الأصلية: تنظيف المكونات وفحص الصورة وإصلاحها. قد يستغرق وقتًا ويحتاج اتصالًا بالإنترنت.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          4002,
          4018
        ]
      ],
      "commands": "DISM /Online /Cleanup-Image /StartComponentCleanup\nDISM /Online /Cleanup-Image /CheckHealth\nDISM /Online /Cleanup-Image /ScanHealth\nDISM /Online /Cleanup-Image /RestoreHealth",
      "sha256": "b5d32e763f92bb06d016852107e14ae3e4bf43b6f86585ea1d57877cdc64f3f8"
    },
    {
      "id": "windows10",
      "category": "fullscreen",
      "title": "إعداد ملء الشاشة — Windows 10",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          4057,
          4077
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_DSEBehavior\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_FSEBehaviorMode\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_EFSEFeatureFlags\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_DXGIHonorFSEWindowsCompatible\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_HonorUserFSEBehaviorMode\" /t REG_DWORD /d \"1\" /f\nreg delete \"HKLM\\SOFTWARE\\Microsoft\\Windows\\Dwm\" /v \"OverlayTestMode\" /f",
      "sha256": "8b33211cba00a7595786977826cbb964a2c9502acaf207c849ac789096ed5672"
    },
    {
      "id": "windows11",
      "category": "fullscreen",
      "title": "إعداد ملء الشاشة — Windows 11",
      "description": "تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          4078,
          4103
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_DSEBehavior\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_FSEBehaviorMode\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_EFSEFeatureFlags\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_DXGIHonorFSEWindowsCompatible\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SYSTEM\\GameConfigStore\" /v \"GameDVR_HonorUserFSEBehaviorMode\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\DirectX\\UserGpuPreferences\" /v \"DirectXUserGlobalSettings\" /t REG_SZ /d \"VRROptimizeEnable=0;SwapEffectUpgradeEnable=1;\" /f\nreg delete \"HKLM\\SOFTWARE\\Microsoft\\Windows\\Dwm\" /v \"OverlayTestMode\" /f",
      "sha256": "73a618bb7c27ffa760a563b570e42eb873bf45d8d4271f1101e3c532996d61c5"
    },
    {
      "id": "revertcomprehensive",
      "category": "revert",
      "title": "تراجع: التحسينات الشاملة",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          520,
          662
        ]
      ],
      "commands": "Reg.exe delete \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"FpsAll\" /f\nReg.exe delete \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"FpsStatusGames\" /f\nReg.exe delete \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"FpsStatusGamesAll\" /f\nReg.exe delete \"HKCU\\SOFTWARE\\Microsoft\\Games\" /v \"GameFluidity\" /f\nbcdedit /set Disabledynamictick yes\nbcdedit /deletevalue useplatformclock\nbcdedit /set useplatformtick yes\nfsutil behavior set memoryusage 1\nfsutil behavior set mftzone 1\nfsutil behavior set Disablinglastaccess 1\nfsutil behavior set Disabledeletenotify 1\nfsutil behavior set encryptpagingfile 0\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Affinity\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Background Only\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"BackgroundPriority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Clock Rate\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"GPU Priority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Priority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Scheduling Category\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"SFIO Priority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency\" /v \"Latency Sensitive\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Affinity\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Background Only\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"BackgroundPriority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Clock Rate\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"GPU Priority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Priority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Scheduling Category\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"SFIO Priority\" /f\nReg.exe delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games\" /v \"Latency Sensitive\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl\" /v \"Win32PrioritySeparation\" /t REG_DWORD /d \"10\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl\" /v \"IRQ8Priority\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\PriorityControl\" /v \"IRQ8Priority\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl\" /v \"IRQ16Priority\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\PriorityControl\" /v \"IRQ16Priority\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"AutoEndTasks\" /t REG_SZ /d \"1\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"HungAppTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"WaitToKillAppTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"LowLevelHooksTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKCU\\Control Panel\\Desktop\" /v \"MenuShowDelay\" /t REG_SZ /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"WaitToKillServiceTimeout\" /t REG_SZ /d \"1000\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability\" /v \"TimeStampInterval\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability\" /v \"IoPriority\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\csrss.exe\\PerfOptions\" /v \"CpuPriorityClass\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\csrss.exe\\PerfOptions\" /v \"IoPriority\" /t REG_DWORD /d \"2\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\DXGKrnl\" /v \"MonitorLatencyTolerance\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\DXGKrnl\" /v \"MonitorRefreshLatencyTolerance\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatency\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"ExitLatencyCheckEnabled\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"Latency\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceDefault\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceFSVP\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyTolerancePerfOverride\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceScreenOffIR\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"LatencyToleranceVSyncEnabled\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"RtlCapabilityCheckLatency\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyActivelyUsed\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleLongTime\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleMonitorOff\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleNoContext\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleShortTime\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultD3TransitionLatencyIdleVeryLongTime\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle0\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle0MonitorOff\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle1\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceIdle1MonitorOff\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceMemory\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceNoContext\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceNoContextMonitorOff\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceOther\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultLatencyToleranceTimerPeriod\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceActivelyUsed\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceMonitorOff\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"DefaultMemoryRefreshLatencyToleranceNoContext\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"Latency\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MaxIAverageGraphicsLatencyInOneBucket\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MiracastPerfTrackGraphicsLatency\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MonitorLatencyTolerance\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"MonitorRefreshLatencyTolerance\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Power\" /v \"TransitionLatency\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\" /v \"SystemResponsiveness\" /t REG_DWORD /d \"14\" /f",
      "sha256": "646e72d84f429f88dc9538f37dd1d1f10463104137aeec21759b7beb115eddc9"
    },
    {
      "id": "revertkeyboard",
      "category": "revert",
      "title": "تراجع: الماوس والكيبورد",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          705,
          748
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\mouclass\\Parameters\" /v \"MouseDataQueueSize\" /t REG_DWORD /d \"256\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\kbdclass\\Parameters\" /v \"KeyboardDataQueueSize\" /t REG_DWORD /d \"256\" /f\nReg.exe delete \"HKCU\\Control Panel\\Accessibility\\Keyboard Response\" /v \"Flags\" /f\nReg.exe delete \"HKCU\\Control Panel\\Accessibility\\ToggleKeys\" /v \"Flags\" /f\nReg.exe delete \"HKCU\\Control Panel\\Accessibility\\StickyKeys\" /v \"Flags\" /f\nReg.exe delete \"HKCU\\Control Panel\\Accessibility\\MouseKeys\" /v \"Flags\" /f\nReg.exe add \"HKCU\\Control Panel\\Mouse\" /v \"MouseSensitivity\" /t REG_SZ /d \"10\" /f\nReg.exe add \"HKCU\\Control Panel\\Keyboard\" /v \"KeyboardDelay\" /t REG_SZ /d \"10\" /f\nReg.exe add \"HKCU\\Control Panel\\Keyboard\" /v \"KeyboardSpeed\" /t REG_SZ /d \"31\" /f",
      "sha256": "4dfe408bf91f6d08097a9acb694b3f98caa6cd8f4e2af823d855a5a621d5c8be"
    },
    {
      "id": "revertwin",
      "category": "revert",
      "title": "تراجع: Windows",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          878,
          1074
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AllowAutoGameMode\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AutoGameModeEnabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"BingSearchEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitInkCollection\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\InputPersonalization\" /v \"RestrictImplicitTextCollection\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Personalization\\Settings\" /v \"AcceptedPrivacyPolicy\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"CortanaCapabilities\" /t REG_SZ /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"IsAssignedAccess\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"IsWindowsHelloActive\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d 1 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchPrivacy\" /t REG_DWORD /d 1 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchSafeSearch\" /t REG_DWORD /d 1 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d 1 /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d 1 /f\nReg.exe add \"HKLM\\Software\\Microsoft\\PolicyManager\\default\\Experience\\AllowCortana\" /v \"value\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\SearchCompanion\" /v \"DisableContentFileUpdates\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCloudSearch\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowCortanaAboveLock\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"AllowSearchToUseLocation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchPrivacy\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWeb\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"ConnectedSearchUseWebOverMeteredConnections\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DisableWebSearch\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\Windows Search\" /v \"DoNotUseWebResults\" /t REG_DWORD /d \"0\" /f\nAuditpol /set /subcategory:\"Process Termination\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"RPC Events\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Filtering Platform Connection\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"DPAPI Activity\" /failure:Disable /failure:Disable\nAuditpol /set /subcategory:\"IPsec Driver\" /success:\t /failure:Enable\nAuditpol /set /subcategory:\"Other System Events\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Security State Change\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"Security System Extension\" /failure:Disable /failure:Enable\nAuditpol /set /subcategory:\"System Integrity\" /failure:Disable /failure:Enable\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\AutoLogger-Diagtrack-Listener\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\DiagLog\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\Diagtrack-Listener\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\System\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiSession\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System\" /v \"AllowExperimentation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\PolicyManager\\default\\System\\AllowExperimentation\" /v \"value\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Feeds\" /v \"EnablingFeeds\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\" /v \"AllowNewsAndInterests\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingActivityFeed\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingActivityFeed\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance\" /v \"MaintenanceDisabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PushNotifications\" /v \"ToastEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\" /v \"NOC_GLOBAL_SETTING_ALLOW_NOTIFICATION_SOUND\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\" /v \"NOC_GLOBAL_SETTING_ALLOW_CRITICAL_TOASTS_ABOVE_LOCK\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\QuietHours\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.AutoPlay\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.LowDisk\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.Print.Notification\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.SecurityAndMaintenance\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings\\Windows.SystemToast.WiFiNetworkManager\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer\" /v \"DisableNotificationCenter\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BTAGService\" /v \"Start\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bthserv\" /v \"Start\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BthAvctpSvc\" /v \"Start\" /t REG_DWORD /d \"3\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\BluetoothUserService\" /v \"Start\" /t REG_DWORD /d \"3\" /f\nsc config DPS start= auto\nsc config DiagTrack start= demand\nsc config dmwappushservice start= demand\nsc config diagnosticshub.standardcollector.service start= demand\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"DoReport\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"LoggingDisabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\PCHealth\\ErrorReporting\" /v \"DoReport\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CDP\" /v \"CdpSessionUserAuthzPolicy\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CDP\" /v \"NearShareChannelUserAuthzPolicy\" /t REG_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\" /v \"SyncPolicy\" /t Reg_DWORD /d \"5\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Accessibility\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\AppSync\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\BrowserSettings\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Credentials\" /v \"Enabled\" /t Reg_DWORD /d \"\"0\"\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\DesktopTheme\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Language\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\PackageState\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Personalization\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\StartLayout\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SettingSync\\Groups\\Windows\" /v \"Enabled\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableAppSyncSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableAppSyncSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableApplicationSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableApplicationSettingSyncUserOverride\" /t Reg_DWORD /d \"1\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableCredentialsSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableCredentialsSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableDesktopThemeSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableDesktopThemeSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisablePersonalizationSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisablePersonalizationSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableStartLayoutSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableStartLayoutSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableSyncOnPaidNetwork\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWebBrowserSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWebBrowserSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWindowsSettingSync\" /t Reg_DWORD /d \"0\" /f\nReg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\SettingSync\" /v \"DisableWindowsSettingSyncUserOverride\" /t Reg_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System\" /v \"EnablingSmartScreen\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\" /v \"SmartScreenEnabled\" /t REG_SZ /d \"On\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AppHost\" /v \"EnablingWebContentEvaluation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"PreInstalledAppsEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"SilentInstalledAppsEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"OemPreInstalledAppsEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"ContentDeliveryAllowed\" /t REG_DWORD /d \"1 /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"SubscribedContentEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager\" /v \"PreInstalledAppsEverEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications\" /v \"GlobalUserDisabled\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKU\\!USER_SID!\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search\" /v \"BackgroundAppGlobalToggle\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\bam\" /v \"Start\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\dam\" /v \"Start\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize\" /v \"EnablingTransparency\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AllowAutoGameMode\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\SOFTWARE\\Microsoft\\GameBar\" /v \"AutoGameModeEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Privacy\" /v \"TailoredExperiencesWithDiagnosticDataEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Diagnostics\\DiagTrack\" /v \"ShowedToastAtLevel\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Software\\Microsoft\\Input\\TIPC\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"UploadUserActivities\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System\" /v \"PublishUserActivities\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_CURRENT_USER\\Control Panel\\International\\User Profile\" /v \"HttpAcceptLanguageOptOut\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Attachments\" /v \"SaveZoneInformation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Diagnostics\\Performance\" /v \"DisablediagnosticTracing\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WDI\\{9c5a40da-b965-4fc3-8781-88dd50a6299d}\" /v \"ScenarioExecutionEnabled\" /t REG_DWORD /d \"1\" /f\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /Enable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /Enable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /Enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\" /Enable",
      "sha256": "b12bf6798a19492c67729d6e01c68e483569d83099be77356fc33db5bf2d0a4f"
    },
    {
      "id": "revertram",
      "category": "revert",
      "title": "تراجع: الذاكرة",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          1905,
          1950
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Enable-MMAgent -MemoryCompression\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\" /v \"SvcHostSplitThresholdInKB\" /t REG_DWORD /d \"3670016\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"LargeSystemCache\" /t REG_DWORD /d \"0\" /f\npowershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; Enable-MMAgent -PageCombining\"\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"DisablePagingExecutive\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\" /v \"DpiMapIommuContiguous\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingPrefetcher\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters\" /v \"EnablingSuperfetch\" /t REG_DWORD /d \"1\" /f",
      "sha256": "486bfaef05743369a34f60460f6447554381e6f210ff80113c58c78d4e71e150"
    },
    {
      "id": "revertcpu",
      "category": "revert",
      "title": "تراجع: المعالج",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2636,
          2709
        ]
      ],
      "commands": "Reg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"64\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet001\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"5\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet002\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"64\" /f\nReg.exe add \"HKLM\\SYSTEM\\ControlSet002\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"5\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMax\" /t REG_DWORD /d \"64\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"5\" /f\nReg.exe delete HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power /v CoreParkingDisabled /f\nbcdedit /deletevalue allowedinmemorysettings\nbcdedit /deletevalue isolatedcontext\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DistributeTimers\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DisableTsx\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\" /v \"EventProcessorEnabled\" /f\npowercfg /setACvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 0\npowercfg /setDCvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 0\npowercfg /setactive SCHEME_CURRENT\nbcdedit /deletevalue {current} numproc\npowercfg -setacvalueindex scheme_current SUB_SLEEP AWAYMODE 1\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current SUB_SLEEP ALLOWSTANDBY 1\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current SUB_SLEEP HYBRIDSLEEP 1\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor PROCTHROTTLEMIN 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor IDLESCALING 0\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor CPMINCORES 10\npowercfg /setactive SCHEME_CURRENT\npowercfg -setacvalueindex scheme_current sub_processor THROTTLING 1\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583\" /v \"ValueMin\" /t REG_DWORD /d \"5\" /f",
      "sha256": "0ba2e7bad4ffd449142d312c0f46beabc5418462969b83ad30e0f302fff38459"
    },
    {
      "id": "revertusb",
      "category": "revert",
      "title": "تراجع: USB",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          2898,
          2946
        ]
      ],
      "commands": "for /f %%i in ('wmic path Win32_USBController get PNPDeviceID^| findstr /l \"PCI\\VEN_\"') do (\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"AllowIdleIrpInD3\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"D3ColdSupported\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"DeviceSelectiveSuspended\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"EnableSelectiveSuspend\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"EnhancedPowerManagementEnabled\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"SelectiveSuspendEnabled\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Enum\\%%i\\Device Parameters\" /v \"SelectiveSuspendOn\" /f\n)\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\usbxhci\\Parameters\" /v \"ThreadPriority\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\USBHUB3\\Parameters\" /v \"ThreadPriority\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\\Parameters\" /v \"ThreadPriority\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\NDIS\\Parameters\" /v \"ThreadPriority\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\USB\" /v \"DisableSelectiveSuspend\" /t REG_DWORD /d \"0\" /f\nfor /f %%i in ('wmic path Win32_USBController get PNPDeviceID') do set \"str=%%i\" & (\nReg.exe delete \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\Affinity Policy\" /v \"DevicePriority\" /f\nReg.exe delete \"HKLM\\System\\CurrentControlSet\\Enum\\%%i\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties\" /v \"MSISupported\" /f\n)",
      "sha256": "93a5759a18a0b20d7b09edd6d990faec64cd98291e107d9af4b58456f2cc0be8"
    },
    {
      "id": "revertdebloat",
      "category": "revert",
      "title": "تراجع: الخدمات",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.",
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "",
      "requires": [],
      "source": [
        [
          3704,
          3917
        ]
      ],
      "commands": "Reg.exe add \"HKCU\\Software\\Microsoft\\GameBar\" /v \"UseNexusForGameBarEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\GameBar\" /v \"GameDVR_Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"AppCaptureEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"AudioCaptureEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"CursorCaptureEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR\" /v \"HistoricalCaptureEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\System\\GameConfigStore\" /v \"GameDVR_Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\Software\\Policies\\Microsoft\\Windows\\GameDVR\" /v \"AllowgameDVR\" /t REG_DWORD /d \"1\" /f\nsc config xbgm start= demand\nsc config XblAuthManager start= auto\nsc config XblGameSave start= manual\nsc config XboxGipSvc start= demand\nsc config XboxNetApiSvc start= demand\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\DeviceGuard\\Scenarios\\HypervisorEnforcedCodeIntegrity\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard\" /v \"HVCIMATRequired\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"DisableExceptionChainValidation\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel\" /v \"KernelSEHOPEnabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"EnablingCfg\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\" /v \"ProtectionMode\" /t REG_DWORD /d \"1\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettings\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverride\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"FeatureSettingsOverrideMask\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\" /v \"MoveImages\" /t REG_DWORD /d \"0\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\HvHost\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmickvpexchange\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicguestinterface\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicshutdown\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicheartbeat\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicvmsession\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicrdv\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmictimesync\" /v \"Start\" /f\nReg.exe delete \"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\vmicvss\" /v \"Start\" /f\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Consolidator\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\BthSQM\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\KernelCeipTask\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\UsbCeip\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Customer Experience Improvement Program\\Uploader\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\Microsoft Compatibility Appraiser\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\ProgramDataUpdater\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\StartupAppTask\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticDataCollector\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskDiagnostic\\Microsoft-Windows-DiskDiagnosticResolver\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Power Efficiency Diagnostics\\AnalyzeSystem\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyMonitor\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyRefresh\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Shell\\FamilySafetyUpload\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Autochk\\Proxy\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Maintenance\\WinSAT\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Application Experience\\AitAgent\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Application Experience\\AitAgent\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Windows Error Reporting\\QueueReporting\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Windows Error Reporting\\QueueReporting\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\CloudExperienceHost\\CreateObjectTask\"\nschtasks /change /tn \"\\Microsoft\\Windows\\CloudExperienceHost\\CreateObjectTask\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\DiskFootprint\\Diagnostics\"\nschtasks /change /tn \"\\Microsoft\\Windows\\DiskFootprint\\Diagnostics\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\"\nschtasks /change /tn \"\\Microsoft\\Windows\\PI\\Sqm-Tasks\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\"\nschtasks /change /tn \"\\Microsoft\\Windows\\NetTrace\\GatherNetworkInfo\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\AppID\\SmartScreenSpecific\"\nschtasks /change /tn \"\\Microsoft\\Windows\\AppID\\SmartScreenSpecific\" /enable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack2016\" /enable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn2016\" /enable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentLogOn\" /enable\nschtasks /end /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack\"\nschtasks /change /tn \"\\Microsoft\\Office\\OfficeTelemetryAgentFallBack\" /enable\nschtasks /end /tn \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\"\nschtasks /change /tn \"\\Microsoft\\Office\\Office 15 Subscription Heartbeat\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Time Synchronization\\ForceSynchronizeTime\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Time Synchronization\\ForceSynchronizeTime\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Time Synchronization\\SynchronizeTime\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Time Synchronization\\SynchronizeTime\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\WindowsUpdate\\Automatic App Update\"\nschtasks /change /tn \"\\Microsoft\\Windows\\WindowsUpdate\\Automatic App Update\" /enable\nschtasks /end /tn \"\\Microsoft\\Windows\\Device Information\\Device\"\nschtasks /change /tn \"\\Microsoft\\Windows\\Device Information\\Device\" /enable\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\AppModel\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Cellcore\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Circular Kernel Context Logger\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\CloudExperienceHostOobe\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DataMarket\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DefenderApiLogger\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DefenderAuditLogger\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\DiagLog\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\HolographicDevice\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\iclsClient\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\iclsProxy\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\LwtNetLog\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Mellanox-Kernel\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Microsoft-Windows-AssignedAccess-Trace\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Microsoft-Windows-Setup\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\NBSMBLOGGER\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\PEAuthLog\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\RdrLog\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\ReadyBoot\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SetupPlatform\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SetupPlatformTel\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SocketHeciServer\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SpoolerLogger\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\SQMLogger\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TCPIPLOGGER\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TileStore\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\Tpm\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\TPMProvisioningService\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\UBPM\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WdiContextLog\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WFP-IPsec Trace\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiDriverIHVSession\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiDriverIHVSessionRepro\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WiFiSession\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WinPhoneCritical\" /v \"Start\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogEnabling\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WUDF\" /v \"LogLevel\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableThirdPartySuggestions\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent\" /v \"DisableWindowsConsumerFeatures\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\Credssp\" /v \"DebugLogLevel\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\Spooler\" /v \"Start\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\PrintNotify\" /v \"Start\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\MapsBroker\" /v \"Start\" /t REG_DWORD /d \"2\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\Common\\ClientTelemetry\" /v \"DisableTelemetry\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"sendcustomerdata\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\Feedback\" /v \"Enabled\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\Feedback\" /v \"includescreenshot\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Outlook\\Options\\Mail\" /v \"EnableLogging\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Word\\Options\" /v \"EnableLogging\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\Common\\ClientTelemetry\" /v \"SendTelemetry\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"qmEnable\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\" /v \"updatereliabilitydata\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\General\" /v \"shownfirstrunoptin\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\General\" /v \"skydrivesigninoption\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Common\\ptwatson\" /v \"ptwoptin\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\Firstrun\" /v \"Disablemovie\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"Enablelogging\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"EnableUpload\" /t REG_DWORD /d \"1\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\" /v \"EnableFileObfuscation\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"accesssolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"olksolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"onenotesolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"pptsolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"projectsolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"publishersolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"visiosolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"wdsolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedapplications\" /v \"xlsolution\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"agave\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"appaddins\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"comaddins\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"documentfiles\" /t REG_DWORD /d \"0\" /f\nReg.exe add \"HKCU\\Software\\Microsoft\\Office\\16.0\\OSM\\preventedsolutiontypes\" /v \"templatefiles\" /t REG_DWORD /d \"0\" /f",
      "sha256": "4abed69c1ff514b70b6065de51aa5fa6c1542428f925bd794f075f3afcc5fb94"
    },
    {
      "id": "revertstorage",
      "category": "revert",
      "title": "تراجع: التخزين",
      "description": "يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.",
      "risk": "high",
      "warnings": [
        "تغيير حماية ذاكرة الكتابة قد يؤدي إلى فقد البيانات عند انقطاع الطاقة.",
        "التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة."
      ],
      "notes": "أوامر التراجع الأصلية تحتوي معاملات غير صحيحة، وتعيد CacheIsPowerProtected إلى 1؛ ليست استعادة كاملة لسياسة القرص.",
      "requires": [],
      "source": [
        [
          3954,
          4001
        ]
      ],
      "commands": "Reg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdleExitEnergyMicroJoules\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdleExitLatencyMs\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdlePowerMw\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SD\\IdleState\\1\" /v \"IdleTimeLengthMs\" /t REG_DWORD /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdleExitEnergyMicroJoules\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdleExitLatencyMs\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdlePowerMw\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\1\" /v \"IdleTimeLengthMs\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdleExitEnergyMicroJoules\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdleExitLatencyMs\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdlePowerMw\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\2\" /v \"IdleTimeLengthMs\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdleExitEnergyMicroJoules\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdleExitLatencyMs\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdlePowerMw\" /f\nReg.exe delete \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\EnergyEstimation\\Storage\\SSD\\IdleState\\3\" /v \"IdleTimeLengthMs\" /t REG_DWORD /f\nFor /f \"Delims=\" %%k in ('Reg.exe Query HKLM\\SYSTEM\\CurrentControlSet\\Enum /f \"{4d36e967-e325-11ce-bfc1-08002be10318}\" /d /s^|Find \"HKEY\"') do (\nReg.exe delete \"%%k\\Device Parameters\\Disk\" /v UserWriteCacheSetting /f\nReg.exe add \"%%k\\Device Parameters\\Disk\" /v CacheIsPowerProtected /t REG_DWORD /d 1 /f\n)",
      "sha256": "174651189b7c410f4107226a97dbb8c9dfe922436237cf246382f75a0fb8db9c"
    },
    {
      "id": "createrp",
      "category": "revert",
      "title": "إنشاء نقطة استعادة",
      "description": "تفعيل حماية قرص النظام وإنشاء نقطة استعادة جديدة. يظهر الفشل إذا لم تسمح إعدادات Windows بذلك.",
      "risk": "standard",
      "warnings": [],
      "notes": "أصلح أمر PowerShell غير المكتمل وأزيلت رسالة النجاح التي كانت تظهر دون التحقق.",
      "requires": [],
      "source": [
        [
          173,
          192
        ]
      ],
      "commands": "powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; $before=@(Get-ComputerRestorePoint).SequenceNumber; Enable-ComputerRestore -Drive ($env:SystemDrive+'\\'); Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore' -Name SystemRestorePointCreationFrequency -Type DWord -Value 0; Checkpoint-Computer -Description 'AHME Tools restore point' -RestorePointType MODIFY_SETTINGS; if (-not (Get-ComputerRestorePoint | Where-Object { $_.Description -eq 'AHME Tools restore point' -and $_.SequenceNumber -notin $before })) { throw 'Restore point was not found' }\"",
      "sha256": "9dfc01375f5d863f7b3e35ce9458de96e8459e0777a4b25391c778078de98119"
    },
    {
      "id": "restore",
      "category": "revert",
      "title": "فتح استعادة النظام",
      "description": "اختر نقطة استعادة من أداة Windows؛ البرنامج لا يختارها تلقائيًا.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [
        [
          4198,
          4210
        ]
      ],
      "commands": "rstrui.exe",
      "sha256": "c6e67175ace3b1b0c68c55ec76d162c3e3c42537a64873e0054391662b9f4525"
    },
    {
      "id": "startapps",
      "category": "tools",
      "title": "إدارة بدء التشغيل وXbox",
      "description": "يعطّل خدمات Xbox ثم يفتح Autoruns. يتطلب C:\\AzizTools\\autoruns.exe.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [
        "C:\\AzizTools\\autoruns.exe"
      ],
      "source": [
        [
          4178,
          4197
        ]
      ],
      "commands": "sc config xbgm start= disabled\nsc config XblAuthManager start= disabled\nsc config XblGameSave start= disabled\nsc config XboxGipSvc start= disabled\nsc config XboxNetApiSvc start= disabled\nstart C:\\AzizTools\\autoruns.exe",
      "sha256": "bbf4ab0f31263d3d16b56ec0dddab1c2cd173cc80a5415303fbe614ea6a2a55e"
    },
    {
      "id": "taskmgr",
      "category": "tools",
      "title": "فتح مدير المهام",
      "description": "لمراجعة المعالج والذاكرة وكرت الشاشة.",
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "source": [],
      "commands": "start \"\" taskmgr.exe",
      "sha256": "883935e476f932f32e091effe2de111da522b58e49a1b12b4881bd2dd26a9017"
    },
    {
      "id": "revertgpu",
      "category": "revert",
      "title": "تراجع: كرت الشاشة",
      "description": "هذا الخيار غير متاح في الملف الأصلي؛ استخدم نقطة استعادة مناسبة.",
      "disabled": true,
      "risk": "standard",
      "warnings": [],
      "notes": "",
      "requires": [],
      "commands": "",
      "source": []
    }
  ]
};
