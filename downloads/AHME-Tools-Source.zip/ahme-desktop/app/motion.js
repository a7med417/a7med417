'use strict';
(() => {
  const root = document.documentElement;
  const button = document.getElementById('motion-toggle');
  const label = document.getElementById('motion-label');
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  let disabled = false;
  try { disabled = localStorage.getItem('ahme-motion') === 'off'; } catch {}
  function apply() {
    const active = !disabled && !preference.matches;
    root.dataset.motion = active ? 'on' : 'off';
    button.setAttribute('aria-pressed', String(active));
    button.disabled = preference.matches;
    label.textContent = preference.matches ? 'حركة مخفّضة' : active ? 'الحركة مفعّلة' : 'الحركة متوقفة';
    button.title = preference.matches ? 'تقليل الحركة مفعّل في إعدادات جهازك' : 'تشغيل أو إيقاف مؤثرات الواجهة';
  }
  button.addEventListener('click', () => {
    disabled = !disabled;
    try { localStorage.setItem('ahme-motion', disabled ? 'off' : 'on'); } catch {}
    apply();
  });
  preference.addEventListener('change', apply);
  function visibility() { root.dataset.pageHidden = String(document.hidden); }
  document.addEventListener('visibilitychange', visibility);
  visibility(); apply();
})();
