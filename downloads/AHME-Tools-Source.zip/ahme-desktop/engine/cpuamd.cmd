@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Reg.exe add "HKLM\SYSTEM\ControlSet001\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMax" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\ControlSet001\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMin" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\ControlSet002\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMax" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\ControlSet002\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMin" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMax" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMin" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add HKLM\SYSTEM\CurrentControlSet\Control\Power /v CoreParkingDisabled /t REG_DWORD /d 0 /f
if errorlevel 1 set "AHME_FAILED=1"
powercfg -setacvalueindex scheme_current sub_processor CPMINCORES 100
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DistributeTimers" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DisableTsx" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "EventProcessorEnabled" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setACvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 1
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setDCvalueindex scheme_current SUB_PROCESSOR SYSCOOLPOL 1
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
set THREADS=%NUMBER_OF_PROCESSORS% & bcdedit /set {current} numproc %NUMBER_OF_PROCESSORS%
powercfg -setacvalueindex scheme_current SUB_SLEEP AWAYMODE 0
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
powercfg -setacvalueindex scheme_current SUB_SLEEP ALLOWSTANDBY 0
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
powercfg -setacvalueindex scheme_current SUB_SLEEP HYBRIDSLEEP 0
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
powercfg -setacvalueindex scheme_current sub_processor PROCTHROTTLEMIN 100
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
powercfg -setacvalueindex scheme_current sub_processor IDLESCALING 1
if errorlevel 1 set "AHME_FAILED=1"
powercfg /setactive SCHEME_CURRENT
if errorlevel 1 set "AHME_FAILED=1"
powercfg -setacvalueindex scheme_current sub_processor THROTTLING 0
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583" /v "ValueMin" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
