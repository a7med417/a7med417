@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
powershell.exe -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; $before=@(Get-ComputerRestorePoint).SequenceNumber; Enable-ComputerRestore -Drive ($env:SystemDrive+'\'); Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' -Name SystemRestorePointCreationFrequency -Type DWord -Value 0; Checkpoint-Computer -Description 'AHME Tools restore point' -RestorePointType MODIFY_SETTINGS; if (-not (Get-ComputerRestorePoint | Where-Object { $_.Description -eq 'AHME Tools restore point' -and $_.SequenceNumber -notin $before })) { throw 'Restore point was not found' }"
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
