@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\StartupAppTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyUpload"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyUpload" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Maintenance\WinSAT"
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
