@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\StartupAppTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\StartupAppTask" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyUpload"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyUpload" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Autochk\Proxy"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Autochk\Proxy" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Maintenance\WinSAT"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Maintenance\WinSAT" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\AitAgent"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\AitAgent" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Windows Error Reporting\QueueReporting"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Windows Error Reporting\QueueReporting" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\CloudExperienceHost\CreateObjectTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\CloudExperienceHost\CreateObjectTask" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\DiskFootprint\Diagnostics"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\DiskFootprint\Diagnostics" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\PI\Sqm-Tasks"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\PI\Sqm-Tasks" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\NetTrace\GatherNetworkInfo"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\NetTrace\GatherNetworkInfo" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\AppID\SmartScreenSpecific"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\AppID\SmartScreenSpecific" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack2016"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack2016" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn2016"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn2016" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoft\Office\OfficeTelemetryAgentLogOn" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoftd\Office\OfficeTelemetryAgentFallBack"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoftd\Office\OfficeTelemetryAgentFallBack" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\Office 15 Subscription Heartbeat"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoft\Office\Office 15 Subscription Heartbeat" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Time Synchronization\SynchronizeTime"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoft\Windows\Time Synchronization\SynchronizeTime" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\WindowsUpdate\Automatic App Update"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoft\Windows\WindowsUpdate\Automatic App Update" /Disable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Device Information\Device"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /TN "\Microsoft\Windows\Device Information\Device" /Disable
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\InputPersonalization" /v "RestrictImplicitInkCollection" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\InputPersonalization" /v "RestrictImplicitTextCollection" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" /v "SensorPermissionState" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" /v "SensorPermissionState" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogEnable" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogLevel" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DoNotShowFeedbackNotifications" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowCommercialDataPipeline" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowDeviceNameInTelemetry" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "LimitEnhancedDiagnosticDataWindowsAnalytics" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "MicrosoftEdgeDataOptIn" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\Siuf\Rules" /v "NumberOfSIUFInPeriod" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\Siuf\Rules" /v "PeriodInNanoSeconds" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0" /v "NoExplicitFeedback" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0" /v "NoActiveHelp" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisableInventory" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "AITEnable" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisableUAR" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC" /v "PreventHandwritingDataSharing" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC" /v "DoSvc" /t REG_DWORD /d "3" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocation" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocationScripting" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableSensors" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableWindowsLocationProvider" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "PublishUserActivities" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "EnableActivityFeed" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "UploadUserActivities" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\SQMClient\Windows" /v "CEIPEnable" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\SQMClient\Reliability" /v "CEIPEnable" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\SQMClient\Reliability" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "CEIPEnable" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "DisableOptinExperience" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\SQMClient\IE" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports" /v "PreventHandwritingErrorReports" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\MediaPlayer\Preferences" /v "UsageTracking" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableSoftLanding" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Peernet" /v "Disabled" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config" /v DODownloadMode /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting" /v value /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" /v "HarvestContacts" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\MRT" /v "DontOfferThroughWUAU" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Biometrics" /v "Enabled" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\dmwappushservice" /v "Start" /t REG_DWORD /d "4" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\International\User Profile" /v "HttpAcceptLanguageOptOut" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
