@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
for /f %%t in ('Reg query "HKLM\System\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}" /t REG_SZ /s /e /f "Intel" ^| findstr "HKEY"') do (
Reg.exe add "%%t" /v "Disabling_OverlayDSQualityEnhancement" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "IncreaseFixedSegment" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "AdaptiveVsyncEnabled" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "DisablingPFonDP" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "EnableCompensationForDVI" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "NoFastLinkTrainingForeDP" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "ACPowerPolicyVersion" /t REG_DWORD /d "16898" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "%%t" /v "DCPowerPolicyVersion" /t REG_DWORD /d "16642" /f
if errorlevel 1 set "AHME_FAILED=1"
)
Reg.exe add "HKLM\Software\Intel\GMM" /v "DedicatedSegmentSize" /t REG_DWORD /d "512" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
