'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { quotePS } = require('./runner.cjs');
const SERVICES = Object.freeze({
  WSearch: ['فهرسة البحث', 'قد يصبح البحث عن الملفات أبطأ أو غير مكتمل أثناء إيقاف الفهرسة.'],
  Spooler: ['خدمة الطباعة', 'لن تتمكن من الطباعة، بما فيها الطباعة إلى PDF، حتى تشغيل الخدمة.'],
  XblAuthManager: ['تسجيل دخول Xbox', 'قد يتوقف تسجيل الدخول إلى Xbox وبعض الألعاب.'],
  XboxNetApiSvc: ['شبكة Xbox', 'قد تتأثر الألعاب الجماعية وخدمات شبكة Xbox.']
});
const CATEGORIES = ['temp', 'shaders', 'thumbnails'];
function validate(op, data = {}) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('طلب غير صالح.');
  if (['apps', 'services', 'metrics'].includes(op)) return { op };
  if (op === 'scan' && Array.isArray(data.categories) && data.categories.length > 0 && data.categories.length <= 3 && data.categories.every(id => CATEGORIES.includes(id))) return { op, categories: [...new Set(data.categories)] };
  if (['trim', 'close'].includes(op) && Number.isSafeInteger(data.id) && data.id > 0 && typeof data.start === 'string' && /^\d{15,20}$/.test(data.start)) return { op, target: { id: data.id, start: data.start } };
  if (op === 'service' && Object.hasOwn(SERVICES, data.id) && ['start', 'stop'].includes(data.action)) return { op, id: data.id, action: data.action };
  if (op === 'clean' && typeof data.token === 'string' && /^[0-9a-f]{32}$/.test(data.token)) return { op, token: data.token };
  throw new Error('الخيار أو البيانات غير صالحة.');
}
function createMetrics(source = os) {
  let previous;
  return () => {
    const cpus = source.cpus();
    const now = cpus.reduce((a, c) => ({ idle: a.idle + c.times.idle, total: a.total + Object.values(c.times).reduce((x, y) => x + y, 0) }), { idle: 0, total: 0 });
    const delta = previous && now.total - previous.total;
    const cpu = delta > 0 ? Math.max(0, Math.min(100, Math.round(100 * (1 - (now.idle - previous.idle) / delta)))) : null;
    previous = now;
    return { total: source.totalmem(), free: source.freemem(), cpu };
  };
}
function verifiedRead(file, digest, variable) {
  return `$${variable}Bytes = [IO.File]::ReadAllBytes(${quotePS(file)}); $hasher = [Security.Cryptography.SHA256]::Create(); try { $hash = [BitConverter]::ToString($hasher.ComputeHash($${variable}Bytes)).Replace('-','').ToLowerInvariant() } finally { $hasher.Dispose() }; if ($hash -ne '${digest}') { throw 'Maintenance file verification failed.' }; $${variable} = [Text.Encoding]::UTF8.GetString($${variable}Bytes);`;
}
function buildWorker(scriptPath, scriptHash, requestPath, requestHash, resultPath) {
  return `$ErrorActionPreference='Stop'; try { ${verifiedRead(scriptPath, scriptHash, 'module')} ${verifiedRead(requestPath, requestHash, 'requestText')} . ([scriptblock]::Create($module)); $request = ConvertFrom-Json $requestText; $data = Invoke-AhmeMaintenance $request; $result = @{ok=$true;data=$data} } catch { $result = @{ok=$false;error=$_.Exception.Message} }; [IO.File]::WriteAllText(${quotePS(resultPath)}, ($result | ConvertTo-Json -Depth 12 -Compress), (New-Object Text.UTF8Encoding($false)));`;
}
function invokeNative(root, dataDir, request) {
  if (process.platform !== 'win32') return Promise.reject(new Error('تحتاج هذه العملية نسخة Windows.'));
  const runs = path.join(dataDir, 'runs'); fs.mkdirSync(runs, { recursive: true });
  const dir = fs.mkdtempSync(path.join(runs, 'care-'));
  const script = fs.readFileSync(path.join(root, 'engine/maintenance.ps1'));
  const payload = Buffer.from(JSON.stringify(request), 'utf8');
  const scriptPath = path.join(dir, 'maintenance.ps1'), requestPath = path.join(dir, 'request.json'), resultPath = path.join(dir, 'result.json');
  fs.writeFileSync(scriptPath, script); fs.writeFileSync(requestPath, payload);
  const sha = b => crypto.createHash('sha256').update(b).digest('hex');
  const worker = buildWorker(scriptPath, sha(script), requestPath, sha(payload), resultPath);
  const encoded = Buffer.from(worker, 'utf16le').toString('base64');
  const exe = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const elevate = request.op === 'service';
  const command = elevate ? `$ErrorActionPreference='Stop'; try { $p = Start-Process -FilePath ${quotePS(exe)} -ArgumentList @('-NoProfile','-NonInteractive','-EncodedCommand','${encoded}') -Verb RunAs -WindowStyle Hidden -Wait -PassThru; exit $p.ExitCode } catch { exit 1 }` : worker;
  return new Promise((resolve, reject) => {
    const child = spawn(exe, ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(command, 'utf16le').toString('base64')], { windowsHide: true, stdio: 'ignore' });
    child.once('error', reject);
    child.once('close', code => {
      try {
        if (!fs.existsSync(resultPath)) throw new Error(elevate ? 'لم تصل نتيجة العملية؛ ربما أُلغيت صلاحية المسؤول. حدّث حالة الخدمات قبل المحاولة مجددًا.' : `تعذر تشغيل أداة Windows (رمز ${code}).`);
        const result = JSON.parse(fs.readFileSync(resultPath, 'utf8'));
        if (!result.ok) throw new Error(result.error);
        resolve(result.data);
      } catch (error) { reject(error); }
      finally {
        // Scans contain cache paths. Keep results only for actual write operations.
        if (['apps', 'services', 'scan'].includes(request.op)) fs.rmSync(dir, { recursive: true, force: true });
      }
    });
  });
}
function createController({ native, confirm, getBusy, setBusy, metrics = createMetrics(), clock = Date.now }) {
  let plan, reading = false;
  const mutations = new Set(['clean', 'trim', 'close', 'service']);
  async function call(op, data) {
    const request = validate(op, data);
    if (op === 'metrics') return metrics();
    if (!mutations.has(op)) {
      if (reading || getBusy()) throw new Error('انتظر انتهاء العملية الحالية.');
      reading = true;
      try {
        const result = await native(request);
        if (op !== 'scan') return result;
        const token = crypto.randomBytes(16).toString('hex');
        plan = { token, expires: clock() + 300000, files: result.files };
        return { token, count: result.files.length, bytes: result.files.reduce((sum, f) => sum + f.size, 0), skipped: result.skipped, truncated: result.truncated };
      } finally { reading = false; }
    }
    if (getBusy() || reading) throw new Error('انتظر انتهاء العملية الحالية.');
    setBusy(true);
    try {
      let detail;
      if (op === 'clean') {
        if (!plan || plan.token !== request.token || plan.expires < clock()) throw new Error('انتهت صلاحية المعاينة. افحص الملفات من جديد.');
        detail = `حذف ${plan.files.length} ملف كاش قديم نهائيًا من الفئات المختارة؟ تُتجاوز الملفات التي تغيرت أو قيد الاستخدام. قد يعاد إنشاء الكاش بعد التنظيف.`;
      } else if (op === 'service') {
        detail = `${request.action === 'stop' ? 'إيقاف' : 'تشغيل'} ${SERVICES[request.id][0]}؟\n${SERVICES[request.id][1]}\nنوع بدء التشغيل لا يتغير. قد يعيد Windows تشغيل الخدمة تلقائيًا. سيُطلب إذن المسؤول.`;
      } else {
        detail = op === 'trim' ? 'تحرير الذاكرة المقيمة للتطبيق المحدد مؤقتًا؟ قد يعيد تحميلها وتتأخر استجابته التالية. هذا لا يمسح كامل كاش الرام ولا يضمن تسريع الجهاز.' : 'إرسال طلب إغلاق للتطبيق المحدد؟ احفظ عملك أولًا. قد يطلب التطبيق حفظ الملفات أو يرفض الإغلاق؛ لا يُغلق بالقوة.';
      }
      if (!await confirm(detail)) return { cancelled: true };
      if (op === 'clean') {
        if (plan.expires < clock()) throw new Error('انتهت صلاحية المعاينة. افحص الملفات من جديد.');
        request.files = plan.files; delete request.token; plan = null;
      }
      return await native(request);
    } finally { setBusy(false); }
  }
  return { call };
}
module.exports = { validate, createMetrics, buildWorker, invokeNative, createController, SERVICES };
