# Loaded by a hash-checked launcher. Windows PowerShell 5.1 compatible.
$ErrorActionPreference = 'Stop'
$script:ServiceNames = @('WSearch', 'Spooler', 'XblAuthManager', 'XboxNetApiSvc')
$script:ExcludedApps = @('AHME-Tools', 'electron', 'explorer', 'powershell', 'pwsh', 'cmd', 'conhost', 'SystemSettings', 'ApplicationFrameHost', 'Taskmgr', 'WindowsTerminal')

function Test-PlainPath([string]$Path) {
    # Check the entire existing ancestry, not just the leaf, for junctions/symlinks.
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return $false }
        }
        $parent = [IO.Path]::GetDirectoryName($current)
        if ($parent -eq $current) { break }
        $current = $parent
    }
    return $true
}
function Get-CleanRoots {
    $local = [Environment]::GetFolderPath('LocalApplicationData')
    if (!$local) { throw 'Local application data folder is unavailable.' }
    return @{
        temp = @{ path = (Join-Path $local 'Temp'); days = 7; pattern = '*'; recurse = $true }
        shaders = @{ path = (Join-Path $local 'D3DSCache'); days = 1; pattern = '*'; recurse = $true }
        thumbnails = @{ path = (Join-Path $local 'Microsoft\Windows\Explorer'); days = 1; pattern = 'thumbcache_*.db'; recurse = $false }
    }
}
function Get-CleanCandidates($Roots, $Categories) {
    $files = New-Object 'System.Collections.Generic.List[object]'
    $skipped = 0; $visited = 0; $truncated = $false
    foreach ($category in $Categories) {
        if (!$Roots.ContainsKey([string]$category)) { throw 'Unknown cleanup category.' }
        $rule = $Roots[$category]
        if (!(Test-Path -LiteralPath $rule.path)) { continue }
        if (!(Test-PlainPath $rule.path)) { $skipped++; continue }
        $stack = New-Object 'System.Collections.Generic.Stack[string]'
        $stack.Push($rule.path)
        while ($stack.Count -gt 0) {
            $directory = $stack.Pop()
            if (!(Test-PlainPath $directory)) { $skipped++; continue }
            try { $entries = @(Get-ChildItem -LiteralPath $directory -Force -ErrorAction Stop) }
            catch { $skipped++; continue }
            foreach ($entry in $entries) {
                $visited++
                if ($visited -gt 50000 -or $files.Count -ge 10000) { $truncated = $true; break }
                if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { $skipped++; continue }
                if ($entry.PSIsContainer) { if ($rule.recurse) { $stack.Push($entry.FullName) }; continue }
                if ($entry.Name -notlike $rule.pattern -or $entry.LastWriteTimeUtc -ge [DateTime]::UtcNow.AddDays(-$rule.days)) { continue }
                $files.Add(@{ category = $category; path = $entry.FullName; size = $entry.Length; stamp = $entry.LastWriteTimeUtc.Ticks.ToString() })
            }
            if ($truncated) { break }
        }
        if ($truncated) { break }
    }
    return @{ files = @($files.ToArray()); skipped = $skipped; truncated = $truncated }
}
function Invoke-CleanPlan($Roots, $Files) {
    $deleted = 0; [long]$bytes = 0; $skipped = 0
    if (@($Files).Count -gt 10000) { throw 'Cleanup plan exceeds limit.' }
    foreach ($file in $Files) {
        try {
            if (!$Roots.ContainsKey([string]$file.category)) { throw 'Unknown category.' }
            $rule = $Roots[$file.category]
            $root = [IO.Path]::GetFullPath($rule.path).TrimEnd('\') + '\'
            $full = [IO.Path]::GetFullPath([string]$file.path)
            if (!$full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or !(Test-PlainPath $full)) { throw 'Path outside plain cache root.' }
            if (!$rule.recurse -and [IO.Path]::GetDirectoryName($full) -ne $root.TrimEnd('\')) { throw 'Nested path rejected.' }
            $item = Get-Item -LiteralPath $full -Force
            if ($item.PSIsContainer -or $item.Name -notlike $rule.pattern -or $item.LastWriteTimeUtc -ge [DateTime]::UtcNow.AddDays(-$rule.days) -or $item.LastWriteTimeUtc.Ticks.ToString() -ne $file.stamp -or $item.Length -ne $file.size) { throw 'File changed since scan.' }
            # No recursive deletion; locked/read-only files are skipped.
            [IO.File]::Delete($full)
            $deleted++; $bytes += [long]$file.size
        } catch { $skipped++ }
    }
    return @{ deleted = $deleted; bytes = $bytes; skipped = $skipped }
}
function Get-VisibleApps {
    $session = (Get-Process -Id $PID).SessionId
    $result = @()
    foreach ($p in @(Get-Process)) {
        try {
            if ($p.MainWindowHandle -eq 0 -or $p.SessionId -ne $session -or $script:ExcludedApps -contains $p.ProcessName) { continue }
            $result += @{ id = $p.Id; start = $p.StartTime.ToUniversalTime().Ticks.ToString(); name = $p.ProcessName; memory = $p.WorkingSet64 }
        } catch { continue }
    }
    return @($result | Sort-Object { $_.memory } -Descending)
}
function Get-SelectedApp($Target) {
    $p = Get-Process -Id ([int]$Target.id)
    if ($p.Id -eq $PID -or $p.MainWindowHandle -eq 0 -or $p.SessionId -ne (Get-Process -Id $PID).SessionId -or $script:ExcludedApps -contains $p.ProcessName -or $p.StartTime.ToUniversalTime().Ticks.ToString() -ne [string]$Target.start) { throw 'Application changed or is not an eligible visible application. Refresh the list.' }
    return $p
}
function Initialize-MemoryApi {
    if ('AhmeMemory' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class AhmeMemory {
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] public static extern bool GetProcessTimes(IntPtr process, out long creation, out long exit, out long kernel, out long user);
    [DllImport("psapi.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] public static extern bool EmptyWorkingSet(IntPtr process);
    [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)] public static extern bool CloseHandle(IntPtr handle);
}
'@
}
function Invoke-AppAction($Target, [string]$Action) {
    $p = Get-SelectedApp $Target
    if ($Action -eq 'close') { return @{ requested = $p.CloseMainWindow() } }
    if ($Action -ne 'trim') { throw 'Unknown app operation.' }
    Initialize-MemoryApi
    [long]$before = $p.WorkingSet64
    $handle = [AhmeMemory]::OpenProcess(0x0500, $false, $p.Id)
    if ($handle -eq [IntPtr]::Zero) { throw 'Windows refused access to this application.' }
    try {
        [long]$created = 0; [long]$exited = 0; [long]$kernel = 0; [long]$user = 0
        if (![AhmeMemory]::GetProcessTimes($handle, [ref]$created, [ref]$exited, [ref]$kernel, [ref]$user) -or [DateTime]::FromFileTimeUtc($created).Ticks.ToString() -ne [string]$Target.start) { throw 'Application identity changed.' }
        if (![AhmeMemory]::EmptyWorkingSet($handle)) { throw ('Windows refused memory trimming: ' + [Runtime.InteropServices.Marshal]::GetLastWin32Error()) }
        $p.Refresh()
        return @{ before = $before; after = $p.WorkingSet64 }
    } finally { [void][AhmeMemory]::CloseHandle($handle) }
}
function Get-OptionalServices {
    return @(foreach ($name in $script:ServiceNames) {
        $service = Get-Service -Name $name -ErrorAction SilentlyContinue
        if ($service) { @{ id = $name; status = $service.Status.ToString() } }
    })
}
function Invoke-OptionalService([string]$Name, [string]$Action) {
    if ($script:ServiceNames -notcontains $Name) { throw 'Service not allowed.' }
    if ($Action -notin @('stop', 'start')) { throw 'Unknown service operation.' }
    $service = Get-Service -Name $Name
    if ($Action -eq 'stop') {
        if (@($service.DependentServices | Where-Object { $_.Status -eq 'Running' }).Count -gt 0) { throw 'Running dependent services prevent stopping this service.' }
        Stop-Service -InputObject $service -ErrorAction Stop
        $service.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(20))
    } else {
        Start-Service -InputObject $service -ErrorAction Stop
        $service.WaitForStatus('Running', [TimeSpan]::FromSeconds(20))
    }
    $service.Refresh()
    return @{ id = $Name; status = $service.Status.ToString() }
}
function Invoke-AhmeMaintenance($Request) {
    switch ([string]$Request.op) {
        'scan' { return Get-CleanCandidates (Get-CleanRoots) @($Request.categories) }
        'clean' { return Invoke-CleanPlan (Get-CleanRoots) @($Request.files) }
        'apps' { return @{ apps = @(Get-VisibleApps) } }
        'trim' { return Invoke-AppAction $Request.target 'trim' }
        'close' { return Invoke-AppAction $Request.target 'close' }
        'services' { return @{ services = @(Get-OptionalServices) } }
        'service' { return Invoke-OptionalService $Request.id $Request.action }
        default { throw 'Unknown maintenance operation.' }
    }
}
