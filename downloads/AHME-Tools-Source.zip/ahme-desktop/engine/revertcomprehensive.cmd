@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Reg.exe delete "HKCU\SOFTWARE\Microsoft\Games" /v "FpsAll" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\SOFTWARE\Microsoft\Games" /v "FpsStatusGames" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\SOFTWARE\Microsoft\Games" /v "FpsStatusGamesAll" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\SOFTWARE\Microsoft\Games" /v "GameFluidity" /f
if errorlevel 1 set "AHME_FAILED=1"
bcdedit /set Disabledynamictick yes
if errorlevel 1 set "AHME_FAILED=1"
bcdedit /deletevalue useplatformclock
if errorlevel 1 set "AHME_FAILED=1"
bcdedit /set useplatformtick yes
if errorlevel 1 set "AHME_FAILED=1"
fsutil behavior set memoryusage 1
if errorlevel 1 set "AHME_FAILED=1"
fsutil behavior set mftzone 1
if errorlevel 1 set "AHME_FAILED=1"
fsutil behavior set Disablinglastaccess 1
if errorlevel 1 set "AHME_FAILED=1"
fsutil behavior set Disabledeletenotify 1
if errorlevel 1 set "AHME_FAILED=1"
fsutil behavior set encryptpagingfile 0
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "Affinity" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "Background Only" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "BackgroundPriority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "Clock Rate" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "GPU Priority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "Priority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "Scheduling Category" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "SFIO Priority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Low Latency" /v "Latency Sensitive" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Affinity" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Background Only" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "BackgroundPriority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Clock Rate" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "SFIO Priority" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Latency Sensitive" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v "Win32PrioritySeparation" /t REG_DWORD /d "10" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v "IRQ8Priority" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\ControlSet001\Control\PriorityControl" /v "IRQ8Priority" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v "IRQ16Priority" /t REG_DWORD /d "2" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\ControlSet001\Control\PriorityControl" /v "IRQ16Priority" /t REG_DWORD /d "2" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Desktop" /v "AutoEndTasks" /t REG_SZ /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Desktop" /v "HungAppTimeout" /t REG_SZ /d "1000" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Desktop" /v "WaitToKillAppTimeout" /t REG_SZ /d "1000" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Desktop" /v "LowLevelHooksTimeout" /t REG_SZ /d "1000" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control" /v "WaitToKillServiceTimeout" /t REG_SZ /d "1000" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability" /v "TimeStampInterval" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability" /v "IoPriority" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d "3" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions" /v "IoPriority" /t REG_DWORD /d "2" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Services\DXGKrnl" /v "MonitorLatencyTolerance" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Services\DXGKrnl" /v "MonitorRefreshLatencyTolerance" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "ExitLatency" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "ExitLatencyCheckEnabled" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "Latency" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "LatencyToleranceDefault" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "LatencyToleranceFSVP" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "LatencyTolerancePerfOverride" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "LatencyToleranceScreenOffIR" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "LatencyToleranceVSyncEnabled" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "RtlCapabilityCheckLatency" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultD3TransitionLatencyActivelyUsed" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultD3TransitionLatencyIdleLongTime" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultD3TransitionLatencyIdleMonitorOff" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultD3TransitionLatencyIdleNoContext" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultD3TransitionLatencyIdleShortTime" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultD3TransitionLatencyIdleVeryLongTime" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceIdle0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceIdle0MonitorOff" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceIdle1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceIdle1MonitorOff" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceMemory" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceNoContext" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceNoContextMonitorOff" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceOther" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultLatencyToleranceTimerPeriod" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultMemoryRefreshLatencyToleranceActivelyUsed" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultMemoryRefreshLatencyToleranceMonitorOff" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "DefaultMemoryRefreshLatencyToleranceNoContext" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "Latency" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "MaxIAverageGraphicsLatencyInOneBucket" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "MiracastPerfTrackGraphicsLatency" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "MonitorLatencyTolerance" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "MonitorRefreshLatencyTolerance" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power" /v "TransitionLatency" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d "14" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
