@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Reg.exe add "HKCU\Software\Microsoft\GameBar" /v "UseNexusForGameBarEnabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\GameBar" /v "GameDVR_Enabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AudioCaptureEnabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "CursorCaptureEnabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "HistoricalCaptureEnabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\Software\Policies\Microsoft\Windows\GameDVR" /v "AllowgameDVR" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
sc config xbgm start= demand
if errorlevel 1 set "AHME_FAILED=1"
sc config XblAuthManager start= auto
if errorlevel 1 set "AHME_FAILED=1"
sc config XblGameSave start= manual
if errorlevel 1 set "AHME_FAILED=1"
sc config XboxGipSvc start= demand
if errorlevel 1 set "AHME_FAILED=1"
sc config XboxNetApiSvc start= demand
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "HVCIMATRequired" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DisableExceptionChainValidation" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "KernelSEHOPEnabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "EnablingCfg" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager" /v "ProtectionMode" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "FeatureSettings" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "FeatureSettingsOverride" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "FeatureSettingsOverrideMask" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "MoveImages" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\HvHost" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmickvpexchange" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmicguestinterface" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmicshutdown" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmicheartbeat" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmicvmsession" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmicrdv" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmictimesync" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\vmicvss" /v "Start" /f
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\StartupAppTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\StartupAppTask" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyUpload"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyUpload" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Autochk\Proxy"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Autochk\Proxy" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Maintenance\WinSAT"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Maintenance\WinSAT" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Application Experience\AitAgent"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Application Experience\AitAgent" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Windows Error Reporting\QueueReporting"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Windows Error Reporting\QueueReporting" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\CloudExperienceHost\CreateObjectTask"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\CloudExperienceHost\CreateObjectTask" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\DiskFootprint\Diagnostics"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\DiskFootprint\Diagnostics" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\PI\Sqm-Tasks"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\PI\Sqm-Tasks" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\NetTrace\GatherNetworkInfo"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\NetTrace\GatherNetworkInfo" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\AppID\SmartScreenSpecific"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\AppID\SmartScreenSpecific" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack2016"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack2016" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn2016"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn2016" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Office\Office 15 Subscription Heartbeat"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Office\Office 15 Subscription Heartbeat" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Time Synchronization\SynchronizeTime"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Time Synchronization\SynchronizeTime" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\WindowsUpdate\Automatic App Update"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\WindowsUpdate\Automatic App Update" /enable
if errorlevel 1 set "AHME_FAILED=1"
schtasks /end /tn "\Microsoft\Windows\Device Information\Device"
if errorlevel 1 set "AHME_FAILED=1"
schtasks /change /tn "\Microsoft\Windows\Device Information\Device" /enable
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AppModel" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Circular Kernel Context Logger" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DataMarket" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\HolographicDevice" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\iclsClient" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\iclsProxy" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\LwtNetLog" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Mellanox-Kernel" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-AssignedAccess-Trace" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-Setup" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\NBSMBLOGGER" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\PEAuthLog" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\RdrLog" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\ReadyBoot" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatform" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SocketHeciServer" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SpoolerLogger" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SQMLogger" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TCPIPLOGGER" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TileStore" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Tpm" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TPMProvisioningService" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\UBPM" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WdiContextLog" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WFP-IPsec Trace" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiDriverIHVSession" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiDriverIHVSessionRepro" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiSession" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WinPhoneCritical" /v "Start" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogEnabling" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogLevel" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableThirdPartySuggestions" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Credssp" /v "DebugLogLevel" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\Spooler" /v "Start" /t REG_DWORD /d "2" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\PrintNotify" /v "Start" /t REG_DWORD /d "2" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\MapsBroker" /v "Start" /t REG_DWORD /d "2" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\Common\ClientTelemetry" /v "DisableTelemetry" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common" /v "sendcustomerdata" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common\Feedback" /v "Enabled" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common\Feedback" /v "includescreenshot" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\Mail" /v "EnableLogging" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Word\Options" /v "EnableLogging" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\Common\ClientTelemetry" /v "SendTelemetry" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common" /v "qmEnable" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common" /v "updatereliabilitydata" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common\General" /v "shownfirstrunoptin" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common\General" /v "skydrivesigninoption" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Common\ptwatson" /v "ptwoptin" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\Firstrun" /v "Disablemovie" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM" /v "Enablelogging" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM" /v "EnableUpload" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM" /v "EnableFileObfuscation" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "accesssolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "olksolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "onenotesolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "pptsolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "projectsolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "publishersolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "visiosolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "wdsolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications" /v "xlsolution" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes" /v "agave" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes" /v "appaddins" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes" /v "comaddins" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes" /v "documentfiles" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes" /v "templatefiles" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
