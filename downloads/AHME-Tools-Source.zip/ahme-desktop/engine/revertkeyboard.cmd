@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\mouclass\Parameters" /v "MouseDataQueueSize" /t REG_DWORD /d "256" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters" /v "KeyboardDataQueueSize" /t REG_DWORD /d "256" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Flags" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\Control Panel\Accessibility\ToggleKeys" /v "Flags" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\Control Panel\Accessibility\StickyKeys" /v "Flags" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe delete "HKCU\Control Panel\Accessibility\MouseKeys" /v "Flags" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Mouse" /v "MouseSensitivity" /t REG_SZ /d "10" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Keyboard" /v "KeyboardDelay" /t REG_SZ /d "10" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Control Panel\Keyboard" /v "KeyboardSpeed" /t REG_SZ /d "31" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
