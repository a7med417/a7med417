const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');

const quotePS = value => "'" + value.replaceAll("'", "''") + "'";
const encodePS = value => Buffer.from(value, 'utf16le').toString('base64');
function getAction(catalog, id) {
  const action = catalog.actions.find(a => a.id === id && !a.disabled);
  if (!action || !/^[a-z0-9]+$/.test(id)) throw new Error('خيار غير صالح.');
  return action;
}
function verifyAction(root, action) {
  const bytes = fs.readFileSync(path.join(root, 'engine', action.id + '.cmd'));
  if (crypto.createHash('sha256').update(bytes).digest('hex') !== action.sha256)
    throw new Error('ملف الأوامر تغيّر؛ أعد استخراج نسخة البرنامج الأصلية.');
  return bytes;
}
function buildWorker(runDir, action) {
  const requirements = action.requires.map(p => `if (-not (Test-Path -LiteralPath ${quotePS(p)} -PathType Leaf)) { throw ${quotePS('Missing required file: ' + p)} }`).join('\n');
  return `
$ErrorActionPreference = 'Stop'
$runDir = ${quotePS(runDir)}
$statusFile = Join-Path $runDir 'status.json'
try {
  ${requirements}
  $script = Join-Path $runDir 'action.cmd'
  if ((Get-FileHash -LiteralPath $script -Algorithm SHA256).Hash -ne '${action.sha256}') { throw 'Action checksum mismatch' }
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Administrator permission was not granted' }
  $process = Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\\cmd.exe') -ArgumentList '/d /s /c action.cmd' -WorkingDirectory $runDir -RedirectStandardOutput (Join-Path $runDir 'stdout.log') -RedirectStandardError (Join-Path $runDir 'stderr.log') -Wait -PassThru -WindowStyle Hidden
  @{ code = $process.ExitCode; message = 'Commands finished; inspect the output. A zero exit code does not measure performance or verify every setting.' } | ConvertTo-Json | Set-Content -LiteralPath $statusFile -Encoding UTF8
} catch {
  @{ code = -1; message = $_.Exception.Message } | ConvertTo-Json | Set-Content -LiteralPath $statusFile -Encoding UTF8
  exit 1
}
`;
}
function execute({ root, dataDir, action, onLog, onDone }) {
  if (process.platform !== 'win32') throw new Error('تنفيذ تعديلات النظام متاح على Windows فقط.');
  const bytes = verifyAction(root, action);
  const runDir = path.join(dataDir, 'runs', Date.now() + '-' + action.id);
  fs.mkdirSync(runDir, { recursive: true });
  fs.writeFileSync(path.join(runDir, 'action.cmd'), bytes);
  const worker = buildWorker(runDir, action);
  const psExe = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  // The OS owns the UAC prompt. No command or path is accepted from the renderer.
  const launch = `$ErrorActionPreference='Stop'; try { $p = Start-Process -FilePath ${quotePS(psExe)} -Verb RunAs -ArgumentList '-NoProfile -NonInteractive -EncodedCommand ${encodePS(worker)}' -Wait -PassThru; exit $p.ExitCode } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }`;
  const child = spawn(psExe, ['-NoProfile', '-NonInteractive', '-EncodedCommand', encodePS(launch)], { windowsHide: true, shell: false });
  let launcherError = '', previous = '', finished = false;
  child.stderr.on('data', chunk => { launcherError += chunk.toString(); });
  function readLog() {
    const read = name => { try { return fs.readFileSync(path.join(runDir, name), 'utf8'); } catch { return ''; } };
    const text = read('stdout.log') + '\n' + read('stderr.log');
    if (text !== previous) { previous = text; onLog(text.slice(-200000)); }
  }
  const timer = setInterval(readLog, 600);
  function finish(fallback) {
    if (finished) return;
    finished = true; clearInterval(timer); readLog();
    let result;
    try { result = JSON.parse(fs.readFileSync(path.join(runDir, 'status.json'), 'utf8').replace(/^\uFEFF/, '')); }
    catch { result = { code: -1, message: launcherError || fallback || 'No completion report. UAC may have been cancelled.' }; }
    result.directory = runDir;
    fs.writeFileSync(path.join(runDir, 'result.json'), JSON.stringify({ ...result, action: action.id, title: action.title, date: new Date().toISOString() }, null, 2));
    onDone(result);
  }
  child.on('error', error => finish(error.message));
  child.on('close', () => finish());
  return { runDir };
}
module.exports = { quotePS, encodePS, getAction, verifyAction, buildWorker, execute };
