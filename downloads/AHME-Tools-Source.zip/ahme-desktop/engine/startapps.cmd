@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
sc config xbgm start= disabled
if errorlevel 1 set "AHME_FAILED=1"
sc config XblAuthManager start= disabled
if errorlevel 1 set "AHME_FAILED=1"
sc config XblGameSave start= disabled
if errorlevel 1 set "AHME_FAILED=1"
sc config XboxGipSvc start= disabled
if errorlevel 1 set "AHME_FAILED=1"
sc config XboxNetApiSvc start= disabled
if errorlevel 1 set "AHME_FAILED=1"
start C:\AzizTools\autoruns.exe
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
