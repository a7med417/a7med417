@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Reg.exe add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\System" /v "AllowExperimentation" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\System\AllowExperimentation" /v "value" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
