@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DisallowShaking" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "EnableBalloonTips" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowSyncProviderNotifications" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener" /v "Value" /t REG_SZ /d "Deny" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\Software\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d "1" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
