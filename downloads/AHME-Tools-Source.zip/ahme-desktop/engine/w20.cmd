@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
set "AHME_FAILED=0"
for /f "tokens=2 delims=," %%S in ('whoami /user /fo csv /nh') do set "USER_SID=%%~S"
set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"
echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul
if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"
cmd /c exit 0
Auditpol /set /subcategory:"Process Termination" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"RPC Events" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"Filtering Platform Connection" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"DPAPI Activity" /failure:Disable /failure:Disable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"IPsec Driver" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"Other System Events" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"Security State Change" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"Security System Extension" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Auditpol /set /subcategory:"System Integrity" /failure:Disable /failure:Enable
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\System\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener" /v "Start" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\System\CurrentControlSet\Control\WMI\Autologger\DiagLog" /v "Start" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\System\CurrentControlSet\Control\WMI\Autologger\Diagtrack-Listener" /v "Start" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
Reg.exe add "HKLM\System\CurrentControlSet\Control\WMI\Autologger\WiFiSession" /v "Start" /t REG_DWORD /d "0" /f
if errorlevel 1 set "AHME_FAILED=1"
exit /b %AHME_FAILED%
