const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const runner = require('./engine/runner.cjs');
const maintenance = require('./engine/maintenance.cjs');
const catalog = require('./app/catalog.json');
let window, busy = false;
if (!app.requestSingleInstanceLock()) app.quit();
else app.whenReady().then(() => {
  window = new BrowserWindow({ width: 1380, height: 920, minWidth: 1020, minHeight: 720, backgroundColor: '#101318', autoHideMenuBar: true, title: 'AHME Tools', webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  window.loadFile('app/index.html');
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.on('close', event => {
    if (busy) { event.preventDefault(); dialog.showMessageBoxSync(window, { type: 'info', message: 'انتظر انتهاء العملية الحالية قبل إغلاق البرنامج.', buttons: ['حسنًا'] }); }
  });
});
app.on('second-instance', () => { window?.show(); window?.focus(); });
app.on('window-all-closed', () => app.quit());
function trusted(event) { if (event.sender !== window?.webContents || event.senderFrame !== window.webContents.mainFrame) throw new Error('Invalid sender'); }
const care = maintenance.createController({
  native: request => maintenance.invokeNative(__dirname, app.getPath('userData'), request),
  getBusy: () => busy, setBusy: value => { busy = value; },
  confirm: async detail => (await dialog.showMessageBox(window, { type: 'warning', title: 'العناية بالجهاز', message: 'تأكيد العملية', detail, buttons: ['إلغاء', 'متابعة'], defaultId: 0, cancelId: 0, noLink: true })).response === 1
});
ipcMain.handle('care', (event, op, data) => {
  trusted(event);
  if (process.platform !== 'win32') throw new Error('تحتاج هذه العملية نسخة Windows.');
  return care.call(op, data);
});
ipcMain.handle('settings', (event, key) => {
  trusted(event);
  const settings = { startup: 'ms-settings:startupapps', storage: 'ms-settings:storagesense', power: 'ms-settings:powersleep' };
  if (process.platform !== 'win32' || !Object.hasOwn(settings, key)) throw new Error('خيار غير متاح.');
  return shell.openExternal(settings[key]);
});
ipcMain.handle('info', event => {
  trusted(event);
  return { windows: process.platform === 'win32', platform: os.type() + ' ' + os.release(), cpu: os.cpus()[0]?.model || 'غير معروف', ram: Math.round(os.totalmem() / 1024 ** 3), dependencies: Object.fromEntries(['C:\\AzizTools\\PowerPlan_GUID.pow', 'C:\\AzizTools\\autoruns.exe'].map(p => [p, fs.existsSync(p)])) };
});
ipcMain.handle('run', async (event, id) => {
  trusted(event);
  if (busy) throw new Error('هناك عملية قيد التشغيل.');
  const action = runner.getAction(catalog, id);
  if (process.platform !== 'win32') throw new Error('تنفيذ تعديلات النظام يحتاج Windows.');
  for (const p of action.requires) if (!fs.existsSync(p)) throw new Error('الملف المساعد غير موجود: ' + p);
  runner.verifyAction(__dirname, action);
  const answer = await dialog.showMessageBox(window, { type: 'warning', title: action.title, message: `تشغيل «${action.title}»؟`, detail: [action.description, ...action.warnings, action.notes, 'سيطلب Windows صلاحية المسؤول. لا تعني عودة الأمر دون خطأ تحسن الأداء.'].filter(Boolean).join('\n\n'), buttons: ['إلغاء', 'تشغيل'], defaultId: 0, cancelId: 0, noLink: true });
  if (answer.response !== 1) return { cancelled: true };
  if (busy) throw new Error('هناك عملية قيد التشغيل.');
  busy = true;
  try {
    runner.execute({ root: __dirname, dataDir: app.getPath('userData'), action, onLog: text => window?.webContents.send('log', text), onDone: result => { busy = false; window?.webContents.send('done', result); } });
    return { started: true };
  } catch (error) { busy = false; throw error; }
});
ipcMain.handle('external', (event, key) => {
  trusted(event);
  const links = { discord: 'https://discord.gg/a-z', resources: 'https://drive.google.com/uc?export=download&id=1-SYV4nL3Ffur1WCRiNf1xtl15mn2sA-G' };
  if (!Object.hasOwn(links, key)) throw new Error('Invalid link');
  return shell.openExternal(links[key]);
});
ipcMain.handle('logs', event => { trusted(event); const dir = path.join(app.getPath('userData'), 'runs'); fs.mkdirSync(dir, { recursive: true }); return shell.openPath(dir); });
