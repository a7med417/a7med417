const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desktop', {
  info: () => ipcRenderer.invoke('info'),
  care: (op, data) => ipcRenderer.invoke('care', op, data),
  settings: key => ipcRenderer.invoke('settings', key),
  run: id => ipcRenderer.invoke('run', id),
  external: key => ipcRenderer.invoke('external', key),
  logs: () => ipcRenderer.invoke('logs'),
  onLog: callback => ipcRenderer.on('log', (_event, text) => callback(text)),
  onDone: callback => ipcRenderer.on('done', (_event, result) => callback(result))
});
