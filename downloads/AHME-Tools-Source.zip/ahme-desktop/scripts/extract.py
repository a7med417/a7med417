from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parents[1]
raw=(root/'original/ahme.cmd').read_bytes()
lines=raw.decode('utf-8',errors='replace').splitlines()
labels={}
for i,l in enumerate(lines):
 m=re.fullmatch(r':([A-Za-z0-9_]+)\s*',l)
 if m: labels.setdefault(m[1].lower(),[]).append(i)
all_starts=sorted(i for values in labels.values() for i in values)
def block(label):
 i=labels[label.lower()][0]
 end=next((j for j in all_starts if j>i),len(lines))
 return lines[i+1:end], [i+1,end]
categories=[('general','التحسينات العامة','◈'),('windows','إعدادات Windows','▦'),('input','الماوس والكيبورد','⌨'),('clean','تنظيف الجهاز','◇'),('memory','الذاكرة RAM','▤'),('gpu','كرت الشاشة','▣'),('cpu','المعالج','◉'),('usb','منافذ USB','⌁'),('power','الطاقة','ϟ'),('debloat','الخدمات والتطبيقات','⊞'),('storage','التخزين','▰'),('repair','إصلاح النظام','✚'),('fullscreen','ملء الشاشة','⛶'),('revert','التراجع والاستعادة','↶'),('tools','الأدوات المساعدة','⚙')]
specs=[]
def add(cat,label,title,desc='',parts=None):specs.append((cat,label,title,desc,parts or [label]))
add('general','comprehensive','تطبيق التحسينات الشاملة','تعديلات السجل والإقلاع ونظام الملفات الواردة في السكربت.')
add('input','kbm1','تعديل الماوس والكيبورد','تطبيق قيم الاستجابة وإعدادات أجهزة الإدخال من الملف الأصلي.')
w=[('w16','تعطيل موجز النشاط'),('w3','إعدادات المؤثرات البصرية'),('w2','تعطيل الإشعارات'),('w4','تعديل بحث Windows'),('w5','تعطيل Bluetooth'),('w1','تعطيل الشفافية'),('w7','تعطيل تقارير الأخطاء'),('w8','تعطيل مزامنة الإعدادات'),('w9','تعطيل التشخيص'),('w10','تعطيل تطبيقات الخلفية'),('w11','تعطيل التجارب'),('gmodeon','تفعيل وضع الألعاب'),('gmodeoff','إيقاف وضع الألعاب'),('w13','تعطيل الصيانة التلقائية'),('w14','تعطيل التتبع وبعض التشخيص'),('w15','تعطيل النوافذ المنبثقة'),('w20','تعديل أحداث التدقيق'),('w17','تعطيل SmartScreen'),('w18','منع إعادة تثبيت التطبيقات'),('w19','تعطيل التجارب المشتركة')]
for label,title in w:add('windows',label,title)
add('windows','allwindows','تطبيق مجموعة Windows','المجموعة الأصلية؛ اختر وضع الألعاب من الخيارات المنفصلة عند الحاجة.',['skipg'])
add('clean','c1','إزالة الأجهزة غير المتصلة','يحذف أجهزة PnP ذات الحالة Unknown؛ هذا الخيار لا يحذف الملفات المؤقتة.')
add('clean','c2','فتح تنظيف القرص','فتح أداة Windows لاختيار الملفات التي تريد تنظيفها.')
for size in [4,8,12,16,24,32,48,64,128]:add('memory',f'{size}gb',f'إعداد ذاكرة {size} GB','قيم الذاكرة المحددة في السكربت، مع تعديلات إدارة الذاكرة المشتركة.',[f'{size}gb','rest'])
for label,title in [('gpunvidia','NVIDIA'),('gpuamd','AMD Radeon'),('gpuintel','Intel Graphics')]:add('gpu',label,f'تعديلات {title}','اختر الشركة المطابقة لكرت الشاشة؛ لا يوجد تراجع مخصص لهذا القسم في الأصل.')
for label,title in [('cpuintel','Intel'),('cpuamd','AMD')]:add('cpu',label,f'تعديلات معالج {title}','يغيّر سياسات المعالج والطاقة والإقلاع، وقد يزيد الحرارة واستهلاك الطاقة.')
add('usb','usb','تعديل إدارة طاقة USB','تعديلات توفير الطاقة لأجهزة ومنافذ USB.')
add('power','power1','استيراد خطة Aziz للطاقة','يتطلب الملف C:\\AzizTools\\PowerPlan_GUID.pow؛ يفتح خيارات الطاقة لاختيار الخطة.')
add('power','power2','تعطيل تسجيل بيانات الطاقة')
add('power','powerc','فتح خيارات الطاقة','يفتح لوحة تحكم الطاقة فقط، ولا يعطّل خدمات Xbox.')
d=[('d1','تعطيل Game DVR'),('d2','تعطيل Telemetry'),('d3','تعطيل خدمات Xbox'),('d4','تعطيل Hyper-V'),('d5','تعطيل بيانات Office'),('d6','تعطيل الطباعة والخرائط'),('d7','إزالة Cortana'),('d12','تعطيل البصمة والتعرف الحيوي'),('d9','تعطيل Autologgers'),('d10','تعطيل برنامج تجربة العملاء'),('alldebloat','تطبيق مجموعة إزالة الخدمات')]
for label,title in d:add('debloat',label,title)
add('storage','storage','تعديل التخزين وذاكرة الكتابة','يغيّر سياسة التخزين المؤقت ويفترض حماية ذاكرة القرص من انقطاع الكهرباء؛ قد يسبب فقد بيانات إذا لم تكن الحماية موجودة.')
add('repair','fixfiles','فحص وإصلاح Windows','تشغيل أوامر DISM الأصلية: تنظيف المكونات وفحص الصورة وإصلاحها. قد يستغرق وقتًا ويحتاج اتصالًا بالإنترنت.')
for v in [10,11]:add('fullscreen',f'windows{v}',f'إعداد ملء الشاشة — Windows {v}')
for label,title in [('revertcomprehensive','التحسينات الشاملة'),('revertkeyboard','الماوس والكيبورد'),('revertwin','Windows'),('revertram','الذاكرة'),('revertcpu','المعالج'),('revertusb','USB'),('revertdebloat','الخدمات'),('revertstorage','التخزين')]:add('revert',label,f'تراجع: {title}','يشغّل قيم التراجع المكتوبة في الأصل؛ لا يسترجع نسخة من إعدادات جهازك السابقة.')
add('revert','createRP','إنشاء نقطة استعادة','تفعيل حماية قرص النظام وإنشاء نقطة استعادة جديدة. يظهر الفشل إذا لم تسمح إعدادات Windows بذلك.')
add('revert','restore','فتح استعادة النظام','اختر نقطة استعادة من أداة Windows؛ البرنامج لا يختارها تلقائيًا.')
add('tools','startapps','إدارة بدء التشغيل وXbox','يعطّل خدمات Xbox ثم يفتح Autoruns. يتطلب C:\\AzizTools\\autoruns.exe.')
add('tools','taskmgr','فتح مدير المهام','لمراجعة المعالج والذاكرة وكرت الشاشة.')
custom={
 'taskmgr':['start "" taskmgr.exe'],
 'createRP':["powershell.exe -NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; $before=@(Get-ComputerRestorePoint).SequenceNumber; Enable-ComputerRestore -Drive ($env:SystemDrive+'\\'); Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore' -Name SystemRestorePointCreationFrequency -Type DWord -Value 0; Checkpoint-Computer -Description 'AHME Tools restore point' -RestorePointType MODIFY_SETTINGS; if (-not (Get-ComputerRestorePoint | Where-Object { $_.Description -eq 'AHME Tools restore point' -and $_.SequenceNumber -notin $before })) { throw 'Restore point was not found' }\""]
}
notes={
 'w16':'أصلح ربط القائمة: كانت تشير إلى w6 غير الموجود؛ هذا هو قسم موجز النشاط w16.',
 'w20':'أصلح ربط القائمة: كان يشغّل الشفافية بدل قسم أحداث التدقيق w20. بعض معاملات Auditpol الأصلية متعارضة وتحتاج مراجعة.',
 'w1':'اسم القيمة EnablingTransparency مكتوب هكذا في الأصل؛ لم نغيّره إلى قيمة أخرى أو نضمن فعاليته.',
 'w17':'بعض أسماء القيم في الأصل مكتوبة EnablingSmartScreen وEnablingWebContentEvaluation؛ قد لا يتعرف Windows عليها.',
 'comprehensive':'توجد معاملات أصلية غير معتادة مثل Disablinglastaccess؛ تظهر أخطاء تنفيذها في السجل ولا تُخفى.',
 'revertstorage':'أوامر التراجع الأصلية تحتوي معاملات غير صحيحة، وتعيد CacheIsPowerProtected إلى 1؛ ليست استعادة كاملة لسياسة القرص.',
 'powerc':'أُوقِف السقوط غير المقصود إلى قسم startapps بعد فتح لوحة الطاقة.',
 'allwindows':'تم فصل اختيار وضع الألعاب لتجنب تسميات gmodeON/gmodeOFF المكررة في الأصل. قد تفشل معاملات Auditpol الأصلية.',
 'createRP':'أصلح أمر PowerShell غير المكتمل وأزيلت رسالة النجاح التي كانت تظهر دون التحقق.',
}
manifest=[]
for cat,label,title,desc,parts in specs:
 ranges=[]; commands=[]
 if label in custom: commands=custom[label]; ranges=[] if label=='taskmgr' else [block('createRP')[1]]
 else:
  for part in parts:
   source,rng=block(part); ranges.append(rng)
   for line in source:
    st=line.strip()
    if not st or re.match(r'(?i)^(?:@?echo\b|@?echo\.|cls\b|pause\b|timeout\b|chcp\b|goto\b|::|rem\b)',st):continue
    if re.search(r'(?i)\b(goto|set\s+/p|choice)\b',st):raise ValueError((label,st))
    st=re.sub(r'(?i)\s*>\s*nul(?:\s*2>&1)?','',st).rstrip()
    # Make PowerShell errors affect its process exit code; preserve the command itself.
    st=re.sub(r'(?i)^powershell(?:\.exe)?\s+-Command\s+"', 'powershell.exe -NoProfile -NonInteractive -Command "$ErrorActionPreference=\'Stop\'; ',st)
    commands.append(st)
 text='\n'.join(commands)
 risks=[]
 if re.search(r'(?i)bcdedit|FeatureSettingsOverride|SmartScreen|SaveZoneInformation|isolatedcontext',text):risks.append('يعدّل الحماية أو إعدادات الإقلاع؛ قد يقلّل حماية الجهاز.')
 if cat=='memory':risks.append('يتضمن القسم المشترك قيم FeatureSettingsOverride التي قد تعطّل بعض تخفيفات ثغرات المعالج.')
 if cat=='storage' or label=='revertstorage':risks.append('تغيير حماية ذاكرة الكتابة قد يؤدي إلى فقد البيانات عند انقطاع الطاقة.')
 if cat=='cpu':risks.append('قد ترتفع الحرارة ويزيد استهلاك الطاقة؛ لا تستخدمه لمعالجة جهاز يعاني من الحرارة.')
 if label in ['d6','alldebloat']:risks.append('يتضمن تعطيل الطباعة وخدمات أخرى قد تستخدمها.')
 if label=='w5':risks.append('سيؤثر في سماعات وأجهزة الإدخال المتصلة بالبلوتوث.')
 if label=='d12':risks.append('قد يؤثر في تسجيل الدخول بالبصمة وWindows Hello.')
 if label=='c1':risks.append('يحذف تسجيل الأجهزة ذات الحالة Unknown باستخدام pnputil.')
 if label in ['d4','alldebloat']:risks.append('قد يعطّل Hyper-V والأجهزة الافتراضية وميزات تعتمد عليه.')
 if label.startswith('revert'):risks.append('التراجع يعيد قيمًا ثابتة من السكربت، وليس بالضرورة قيم جهازك السابقة.')
 requires=[]
 if label=='power1':requires=['C:\\AzizTools\\PowerPlan_GUID.pow']
 if label=='startapps':requires=['C:\\AzizTools\\autoruns.exe']
 # Record failure immediately after actual commands, including commands inside FOR/IF blocks.
 instrumented=[]
 for cmd in commands:
  instrumented.append(cmd)
  if not re.match(r'(?i)^(?:for\b|if\b|\)|set\b)',cmd) and not cmd.endswith('('):instrumented.append('if errorlevel 1 set "AHME_FAILED=1"')
 header=['@echo off','setlocal EnableExtensions EnableDelayedExpansion','chcp 65001 >nul','set "AHME_FAILED=0"','for /f "tokens=2 delims=," %%S in (\'whoami /user /fo csv /nh\') do set "USER_SID=%%~S"','set "ProcessorManufacturer=%PROCESSOR_IDENTIFIER%"','echo %PROCESSOR_IDENTIFIER% | find /i "AuthenticAMD" >nul','if not errorlevel 1 set "ProcessorManufacturer=AuthenticAMD"','cmd /c exit 0']
 payload='\r\n'.join(header+instrumented+['exit /b %AHME_FAILED%',''])
 dest=root/'engine'/f'{label.lower()}.cmd';dest.write_bytes(payload.encode('utf-8'))
 manifest.append(dict(id=label.lower(),category=cat,title=title,description=desc or 'تطبيق أوامر هذا الخيار من ahme.cmd. يمكنك معاينة الأوامر قبل تشغيلها.',risk='high' if risks else 'standard',warnings=risks,notes=notes.get(label,''),requires=requires,source=ranges,commands=text,sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
manifest.append(dict(id='revertgpu',category='revert',title='تراجع: كرت الشاشة',description='هذا الخيار غير متاح في الملف الأصلي؛ استخدم نقطة استعادة مناسبة.',disabled=True,risk='standard',warnings=[],notes='',requires=[],commands='',source=[]))
(root/'app/catalog.json').write_text(json.dumps(dict(sourceSha256=hashlib.sha256(raw).hexdigest(),categories=[dict(id=i,title=t,icon=c) for i,t,c in categories],actions=manifest),ensure_ascii=False,indent=2),encoding='utf-8')
(root/'app/catalog.js').write_text('window.AHME_CATALOG = '+(root/'app/catalog.json').read_text()+';\n',encoding='utf-8')
print(f'Generated {len(manifest)} catalog entries, {len(manifest)-1} executable actions.')
