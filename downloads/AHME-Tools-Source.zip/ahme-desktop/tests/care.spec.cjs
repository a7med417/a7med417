const { test, expect } = require('@playwright/test');
async function mock(page) {
  await page.addInitScript(() => {
    window.careCalls = [];
    window.desktop = {
      info: async () => ({ windows: true, platform: 'Windows mock', cpu: 'Test CPU', ram: 16 }), onLog: () => {}, onDone: () => {},
      care: async (op, data) => {
        window.careCalls.push({ op, data });
        if (window.failCare === op) throw new Error('Access denied');
        if (window.cancelCare === op) return { cancelled: true };
        return ({
          metrics: { total: 16 * 1024 ** 3, free: 8 * 1024 ** 3, cpu: 24 },
          apps: { apps: [{ id: 42, start: '638924712300000000', name: 'Example editor', memory: 200 * 1024 ** 2 }] },
          scan: { token: 'a'.repeat(32), count: 12, bytes: 100 * 1024 ** 2, skipped: 1, truncated: false },
          clean: { deleted: 10, bytes: 80 * 1024 ** 2, skipped: 2 }, trim: { before: 200 * 1024 ** 2, after: 100 * 1024 ** 2 }, close: { requested: true },
          services: { services: [{ id: 'WSearch', status: 'Running' }, { id: 'Spooler', status: 'Stopped' }] }, service: { id: data?.id, status: data?.action === 'stop' ? 'Stopped' : 'Running' }
        })[op];
      }, settings: async id => { window.settingsCall = id; }
    };
  });
}
test('care preview exposes features without fake live numbers or enabled native actions', async ({ page }) => {
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto('/'); await page.locator('.nav-item[data-category=care]').click();
  await expect(page.locator('#care-section')).toBeVisible(); await expect(page.locator('#tools-section')).toBeHidden();
  await expect(page.locator('#memory-used')).toHaveText('—');
  for (const id of ['scan-cache', 'refresh-apps', 'trim-app', 'refresh-services']) await expect(page.locator('#' + id)).toBeDisabled();
  await page.locator('.nav-item[data-category=home]').click(); await expect(page.locator('.action-card')).toHaveCount(6);
  expect(errors).toEqual([]);
});
test('all themes change the palette, persist, and preserve reduced motion', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' }); await page.goto('/');
  const palettes = [];
  for (const theme of ['aurora', 'ocean', 'violet', 'ember']) {
    await page.locator('#theme').selectOption(theme); await page.reload();
    await expect(page.locator('#theme')).toHaveValue(theme);
    palettes.push(await page.locator('.hero').evaluate(e => getComputedStyle(e).backgroundImage));
    expect(await page.locator('.care-orb').evaluate(e => getComputedStyle(e).animationName)).toBe('none');
  }
  expect(new Set(palettes).size).toBe(4);
});
test('cache requires a scan, invalidates after selection changes, and reports actual partial results', async ({ page }) => {
  await mock(page); await page.goto('/'); await page.locator('#care-entry').click();
  await expect(page.locator('#memory-used')).toHaveText('50%');
  await expect(page.locator('#clean-cache')).toBeDisabled(); await page.locator('#scan-cache').click();
  await expect(page.locator('#scan-result')).toContainText('12 ملف');
  await page.locator('[name=cache][value=shaders]').check(); await expect(page.locator('#clean-cache')).toBeDisabled();
  await page.locator('#scan-cache').click(); await page.locator('#clean-cache').click();
  await expect(page.locator('#scan-result')).toContainText('حُذف 10 ملف'); await expect(page.locator('#scan-result')).toContainText('متجاوزة: 2');
  await expect(page.locator('#clean-cache')).toBeDisabled();
  expect(await page.evaluate(() => window.careCalls.filter(c => c.op === 'clean')[0].data)).toEqual({ token: 'a'.repeat(32) });
});
test('app controls require selection and send process creation time; service failure is never success', async ({ page }) => {
  await mock(page); await page.goto('/'); await page.locator('#care-entry').click();
  await expect(page.locator('#trim-app')).toBeDisabled(); await page.locator('#refresh-apps').click();
  await expect(page.locator('#trim-app')).toBeDisabled(); await page.locator('[name=application]').check(); await page.locator('#trim-app').click();
  expect(await page.evaluate(() => window.careCalls.find(c => c.op === 'trim').data)).toEqual({ id: 42, start: '638924712300000000' });
  await expect(page.locator('#care-status')).toContainText('قد ترتفع مجددًا');
  await page.locator('#refresh-services').click();
  await expect(page.locator('[data-service=WSearch][data-operation=stop]')).toBeEnabled();
  await expect(page.locator('[data-service=Spooler][data-operation=stop]')).toBeDisabled();
  await page.evaluate(() => { window.failCare = 'service'; });
  await page.locator('[data-service=WSearch][data-operation=stop]').click();
  await expect(page.locator('#care-status')).toHaveAttribute('data-state', 'error'); await expect(page.locator('#care-status')).toContainText('Access denied');
});
test('cancelled cleaning stays unexecuted, settings use fixed keys, and care fits desktop viewport', async ({ page }) => {
  await mock(page); await page.setViewportSize({ width: 1060, height: 800 }); await page.goto('/'); await page.locator('#care-entry').click();
  await page.evaluate(() => { window.cancelCare = 'clean'; });
  await page.locator('#scan-cache').click(); await page.locator('#clean-cache').click();
  await expect(page.locator('#care-status')).toContainText('أُلغي'); await expect(page.locator('#scan-result')).not.toContainText('حُذف');
  await page.locator('[data-setting=startup]').click(); expect(await page.evaluate(() => window.settingsCall)).toBe('startup');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});
