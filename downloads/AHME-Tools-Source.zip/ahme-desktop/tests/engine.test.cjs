const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { getAction, verifyAction, buildWorker, quotePS, execute } = require('../engine/runner.cjs');
const catalog = require('../app/catalog.json');
const root = path.resolve(__dirname, '..');
test('all mapped operations have intact scripts and no interactive navigation', () => {
  assert.equal(new Set(catalog.actions.map(a => a.id)).size, catalog.actions.length);
  assert.equal(catalog.actions.length, 71);
  const files = fs.readdirSync(path.join(root, 'engine')).filter(n => n.endsWith('.cmd'));
  assert.equal(files.length, 70);
  for (const action of catalog.actions.filter(a => !a.disabled)) {
    const body = verifyAction(root, action).toString('utf8');
    assert.ok(action.commands.trim(), action.id);
    assert.doesNotMatch(body, /^\s*(?:goto|pause|set\s+\/p|choice)\b/im, action.id);
    assert.match(body, /exit \/b %AHME_FAILED%/);
    assert.doesNotMatch(body, /curl.*(?:-k|--insecure)/i);
  }
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root, 'original/ahme.cmd'))).digest('hex'), catalog.sourceSha256);
});
test('menu bugs are corrected without falling through into unrelated actions', () => {
  assert.match(getAction(catalog, 'w16').commands, /EnableActivityFeed/);
  assert.match(getAction(catalog, 'w20').commands, /Auditpol/);
  assert.doesNotMatch(getAction(catalog, 'powerc').commands, /Xbox|xbgm|autoruns/i);
  for (const size of [4, 8, 12, 16, 24, 32, 48, 64, 128]) {
    const action = getAction(catalog, size + 'gb');
    assert.match(action.commands, /SvcHostSplitThresholdInKB/);
    assert.match(action.commands, /Disable-MMAgent -PageCombining/);
    assert.ok(action.warnings.some(w => w.includes('FeatureSettingsOverride')));
  }
});
test('runner rejects arbitrary IDs, blocked options, and non-Windows execution', () => {
  for (const id of ['../main', 'revertgpu', 'w1 & whoami', 'resources', 'unknown']) assert.throws(() => getAction(catalog, id));
  if (process.platform !== 'win32') assert.throws(() => execute({ root, action: getAction(catalog, 'w1') }), /Windows/);
});
test('elevated worker validates hash and requirements before executing a fixed filename', () => {
  const script = buildWorker("C:\\Users\\O'Brien\\AHME Tools", getAction(catalog, 'startapps'));
  assert.ok(script.indexOf('Test-Path') < script.indexOf('Start-Process'));
  assert.ok(script.indexOf('Get-FileHash') < script.indexOf('Start-Process'));
  assert.match(script, /O''Brien/);
  assert.match(script, /\/d \/s \/c action\.cmd/);
  assert.match(script, /ExitCode/);
  assert.match(script, /IsInRole/);
  assert.equal(quotePS("a'b"), "'a''b'");
});
test('source feature coverage includes every leaf except menus and shared/aliased blocks', () => {
  const source = fs.readFileSync(path.join(root, 'original/ahme.cmd'), 'utf8');
  const labels = [...source.matchAll(/^:([A-Za-z0-9_]+)\s*$/gm)].map(m => m[1].toLowerCase());
  const navigation = new Set(['noadmin', 'welscreen', 'restorepoint', 'resources', 'menu', 'misspellredirect', 'redirectmenu', 'reverts', 'gopt', 'kbm', 'win', 'w12', 'gamemode', 'clean', 'ram', 'rest', 'gpu', 'cpuwarn', 'cpu', 'debloat', 'fullscreen', 'powerr', 'skipg']);
  for (const label of labels) assert.ok(navigation.has(label) || catalog.actions.some(a => a.id === label), 'Unmapped source feature: ' + label);
});
