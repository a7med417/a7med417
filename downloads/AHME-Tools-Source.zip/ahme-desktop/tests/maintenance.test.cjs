const { test } = require('node:test');
const assert = require('node:assert/strict');
const { validate, createMetrics, createController, buildWorker } = require('../engine/maintenance.cjs');
test('maintenance IPC accepts only fixed operations, categories, services and exact process identity', () => {
  for (const [op, data] of [['execute', {}], ['service', { id: 'WinDefend', action: 'stop' }], ['service', { id: '__proto__', action: 'stop' }], ['service', { id: 'Spooler', action: 'disable' }], ['scan', { categories: ['C:\\Users'] }], ['scan', { categories: [] }], ['trim', { id: -1, start: '123' }], ['trim', { id: 4, start: 123456789123456789 }], ['clean', { files: ['C:\\important'] }]]) assert.throws(() => validate(op, data));
  assert.deepEqual(validate('trim', { id: 42, start: '638924712300000000', command: 'ignored' }), { op: 'trim', target: { id: 42, start: '638924712300000000' } });
  assert.deepEqual(validate('scan', { categories: ['temp', 'temp'], root: 'C:\\' }), { op: 'scan', categories: ['temp'] });
});
test('CPU usage is calculated from time deltas; first sample is not a fabricated reading', () => {
  let idle = 100, user = 100;
  const metrics = createMetrics({ cpus: () => [{ times: { idle, user } }], totalmem: () => 1000, freemem: () => 250 });
  assert.deepEqual(metrics(), { total: 1000, free: 250, cpu: null });
  idle += 30; user += 70;
  assert.equal(metrics().cpu, 70);
});
function fixture(confirm = async () => true) {
  let busy = false, time = 1;
  const calls = [];
  const files = [{ category: 'temp', path: 'fixed', size: 123, stamp: '123' }];
  const controller = createController({ native: async request => { calls.push(request); return request.op === 'scan' ? { files, skipped: 0, truncated: false } : { deleted: 1, bytes: 123, skipped: 0 }; }, confirm, getBusy: () => busy, setBusy: value => { busy = value; }, clock: () => time });
  return { ...controller, calls, files, busy: () => busy, expire: () => { time += 300001; } };
}
test('cleanup is a single-use server-owned plan and rejects arbitrary or expired tokens', async () => {
  const c = fixture();
  await assert.rejects(c.call('clean', { token: '0'.repeat(32) }), /انتهت/);
  const plan = await c.call('scan', { categories: ['temp'] });
  assert.equal(plan.count, 1); assert.equal(plan.bytes, 123); assert.equal(plan.files, undefined);
  await c.call('clean', { token: plan.token, files: ['attacker path'] });
  assert.deepEqual(c.calls[1], { op: 'clean', files: c.files });
  await assert.rejects(c.call('clean', { token: plan.token }), /انتهت/);
  const next = await c.call('scan', { categories: ['temp'] }); c.expire();
  await assert.rejects(c.call('clean', { token: next.token }), /انتهت/);
  assert.equal(c.busy(), false);
});
test('native cancellation performs no write and holds the shared lock while confirmation is open', async () => {
  let resolve;
  const c = fixture(() => new Promise(r => { resolve = r; }));
  const pending = c.call('service', { id: 'WSearch', action: 'stop' });
  assert.equal(c.busy(), true);
  await assert.rejects(c.call('service', { id: 'Spooler', action: 'stop' }), /انتظر/);
  resolve(false); assert.deepEqual(await pending, { cancelled: true });
  assert.deepEqual(c.calls, []); assert.equal(c.busy(), false);
});
test('worker checks in-memory bytes for both executable source and JSON payload before invoking', () => {
  const script = buildWorker("C:\\O'Brien\\module.ps1", 'a'.repeat(64), 'request.json', 'b'.repeat(64), 'result.json');
  assert.match(script, /O''Brien/);
  assert.equal((script.match(/ComputeHash/g) || []).length, 2);
  assert.ok(script.indexOf('ComputeHash') < script.indexOf('scriptblock'));
  assert.match(script, /ConvertFrom-Json \$requestText/);
  assert.doesNotMatch(script, /ExecutionPolicy|Invoke-Expression/);
});
