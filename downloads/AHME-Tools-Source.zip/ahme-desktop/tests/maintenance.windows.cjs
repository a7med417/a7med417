// Native bridge integration: run only on Windows. No services are changed.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { invokeNative, buildWorker } = require('../engine/maintenance.cjs');
(async () => {
  assert.equal(process.platform, 'win32');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "ahme-O'Brien-"));
  try {
    const root = path.resolve(__dirname, '..');
    const services = await invokeNative(root, dir, { op: 'services' });
    assert.ok(Array.isArray(services.services));
    const apps = await invokeNative(root, dir, { op: 'apps' });
    assert.ok(Array.isArray(apps.apps));
    const marker = path.join(dir, 'must-not-run.txt');
    const script = path.join(dir, 'module.ps1'), payload = path.join(dir, 'request.json'), result = path.join(dir, 'result.json');
    fs.writeFileSync(script, `[IO.File]::WriteAllText('${marker.replaceAll("'", "''")}', 'bad')`);
    fs.writeFileSync(payload, '{}');
    const worker = buildWorker(script, '0'.repeat(64), payload, '0'.repeat(64), result);
    const exe = path.join(process.env.SystemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe');
    const child = spawnSync(exe, ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(worker, 'utf16le').toString('base64')], { encoding: 'utf8' });
    assert.equal(child.status, 0, child.stderr);
    assert.equal(JSON.parse(fs.readFileSync(result, 'utf8')).ok, false);
    assert.equal(fs.existsSync(marker), false, 'hash mismatch must never execute modified bytes');
    console.log('WINDOWS BRIDGE CHECKS PASSED: services, apps, quoted paths, hash refusal');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
})().catch(error => { console.error(error); process.exitCode = 1; });
