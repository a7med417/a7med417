$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '..\engine\maintenance.ps1')
$script:Assertions = 0
function Assert($Condition, [string]$Message) {
    if (!$Condition) { throw "ASSERTION FAILED: $Message" }
    $script:Assertions++
    Write-Output "PASS: $Message"
}
function Assert-Throws([scriptblock]$Body, [string]$Message) {
    $failed = $false
    try { & $Body | Out-Null } catch { $failed = $true }
    Assert $failed $Message
}
$fixture = Join-Path ([IO.Path]::GetTempPath()) ('ahme-tests-' + [Guid]::NewGuid().ToString('N'))
$cache = Join-Path $fixture 'cache'
$outside = Join-Path $fixture 'cache-outside'
$locked = $null
try {
    [void](New-Item -ItemType Directory -Path $cache, $outside, (Join-Path $cache 'nested'))
    foreach ($name in @('old.bin', 'changed.bin', 'locked.bin', 'readonly.bin', 'nested\old.bin', 'recent.bin')) {
        $file = Join-Path $cache $name
        [IO.File]::WriteAllText($file, 'fixture data')
        if ($name -ne 'recent.bin') { [IO.File]::SetLastWriteTimeUtc($file, [DateTime]::UtcNow.AddDays(-10)) }
    }
    $outsideFile = Join-Path $outside 'outside.bin'
    [IO.File]::WriteAllText($outsideFile, 'keep')
    [IO.File]::SetLastWriteTimeUtc($outsideFile, [DateTime]::UtcNow.AddDays(-10))
    [void](New-Item -ItemType Junction -Path (Join-Path $cache 'junction') -Target $outside)
    $rules = @{ temp = @{ path = $cache; days = 7; pattern = '*'; recurse = $true } }
    $scan = Get-CleanCandidates $rules @('temp')
    Assert ($scan.files.Count -eq 5) 'scan selects old files only'
    Assert ($scan.skipped -ge 1) 'scan skips junctions'
    Assert (!(Test-PlainPath (Join-Path $cache 'junction\outside.bin'))) 'ancestor junction is rejected'
    Assert-Throws { Get-CleanCandidates $rules @('arbitrary-root') } 'unknown cleanup category rejected'
    [IO.File]::AppendAllText((Join-Path $cache 'changed.bin'), 'changed since scan')
    [IO.File]::SetAttributes((Join-Path $cache 'readonly.bin'), [IO.FileAttributes]::ReadOnly)
    $locked = [IO.File]::Open((Join-Path $cache 'locked.bin'), 'Open', 'ReadWrite', 'None')
    $result = Invoke-CleanPlan $rules $scan.files
    Assert ($result.deleted -eq 2) 'only unchanged, unlocked, writable old files deleted'
    Assert ($result.skipped -eq 3) 'locked, changed and read-only files reported as skipped'
    Assert ($result.bytes -eq 24) 'deleted bytes measured from actual candidates'
    Assert (Test-Path (Join-Path $cache 'recent.bin')) 'recent file preserved'
    Assert (Test-Path $outsideFile) 'outside junction target preserved'
    $outsideInfo = Get-Item $outsideFile
    $forged = @{ category = 'temp'; path = $outsideFile; size = $outsideInfo.Length; stamp = $outsideInfo.LastWriteTimeUtc.Ticks.ToString() }
    $rejected = Invoke-CleanPlan $rules @($forged)
    Assert ($rejected.deleted -eq 0 -and $rejected.skipped -eq 1) 'prefix sibling path cannot escape cache root'
    $forged.path = Join-Path $cache 'junction\outside.bin'
    $rejected = Invoke-CleanPlan $rules @($forged)
    Assert ($rejected.deleted -eq 0) 'deletion also rejects junction traversal'
    Assert-Throws { Get-SelectedApp @{ id = $PID; start = (Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks.ToString() } } 'worker and shell processes cannot be selected'
    Assert-Throws { Invoke-OptionalService 'WinDefend' 'stop' } 'essential service rejected before mutation'
    Assert-Throws { Invoke-OptionalService 'Spooler' 'disable' } 'permanent service disabling rejected'
    Assert-Throws { Invoke-AhmeMaintenance @{ op = 'execute'; command = 'not allowed' } } 'unknown native operation rejected'
    $services = @(Get-OptionalServices)
    Assert ($services.Count -ge 1) 'read-only service status works on Windows'
    Initialize-MemoryApi
    $handle = [AhmeMemory]::OpenProcess(0x0500, $false, $PID)
    Assert ($handle -ne [IntPtr]::Zero) 'documented memory API opens test process'
    try {
        [long]$created = 0; [long]$exited = 0; [long]$kernel = 0; [long]$user = 0
        Assert ([AhmeMemory]::GetProcessTimes($handle, [ref]$created, [ref]$exited, [ref]$kernel, [ref]$user)) 'process creation time queried from actual handle'
        Assert ([DateTime]::FromFileTimeUtc($created).Ticks -eq (Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks) 'creation time encoding matches native identity'
        Assert ([AhmeMemory]::EmptyWorkingSet($handle)) 'memory trim primitive runs on disposable test process'
    } finally { [void][AhmeMemory]::CloseHandle($handle) }
    Write-Output "WINDOWS CHECKS PASSED: $script:Assertions"
} finally {
    if ($locked) { $locked.Dispose() }
    $ro = Join-Path $cache 'readonly.bin'
    if (Test-Path $ro) { [IO.File]::SetAttributes($ro, [IO.FileAttributes]::Normal) }
    $junction = Join-Path $cache 'junction'
    if (Test-Path $junction) { [IO.Directory]::Delete($junction) }
    if (Test-Path $fixture) { Remove-Item -LiteralPath $fixture -Recurse -Force }
}
