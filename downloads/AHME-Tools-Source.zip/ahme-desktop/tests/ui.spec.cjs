const { test, expect } = require('@playwright/test');
const catalog = require('../app/catalog.json');
test('dashboard, complete catalog, search and source preview work without executing commands', async ({ page }) => {
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto('/');
  await expect(page.locator('.category-tile')).toHaveCount(15);
  await expect(page.locator('.action-card')).toHaveCount(6);
  await page.screenshot({ path: 'test-results/dashboard.png', fullPage: true, animations: 'disabled' });
  await page.locator('#show-all').click();
  await expect(page.locator('.action-card')).toHaveCount(71);
  await page.locator('#search').fill('NVIDIA');
  await expect(page.locator('.action-card')).toHaveCount(1);
  await page.locator('.open-action').click();
  await expect(page.locator('#detail-title')).toContainText('NVIDIA');
  await page.locator('.command-preview summary').click();
  await expect(page.locator('#command-preview')).toContainText('nvlddmkm');
  await page.locator('#ack').check();
  await expect(page.locator('#execute')).toBeDisabled();
  expect(errors).toEqual([]);
});
test('every source action is reachable and shows its exact command preview', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/'); await page.locator('#show-all').click();
  for (const action of catalog.actions) {
    await page.locator(`[data-action="${action.id}"] .open-action`).click();
    await expect(page.locator('#detail-title')).toHaveText(action.title);
    if (!action.disabled) await expect(page.locator('#command-preview')).toHaveText(action.commands);
    await page.locator('.dialog-heading .close-dialog').click();
  }
});
test('motion runs, can be disabled, and the preference persists across navigation and reload', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto('/');
  await expect(page.locator('#motion-toggle')).toHaveAttribute('aria-pressed', 'true');
  expect(await page.locator('.orbit-outer').evaluate(e => getComputedStyle(e).animationName)).toBe('orbit-spin');
  await page.locator('#motion-toggle').click();
  expect(await page.locator('.orbit-outer').evaluate(e => getComputedStyle(e).animationName)).toBe('none');
  await page.locator('#show-all').click();
  expect(await page.locator('.action-card').first().evaluate(e => getComputedStyle(e).animationName)).toBe('none');
  await page.reload();
  await expect(page.locator('#motion-toggle')).toHaveAttribute('aria-pressed', 'false');
  await page.locator('#motion-toggle').click();
  expect(await page.locator('.orbit-outer').evaluate(e => getComputedStyle(e).animationName)).toBe('orbit-spin');
});
test('OS reduced-motion setting suppresses decorative animation and remains reactive', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await expect(page.locator('#motion-toggle')).toBeDisabled();
  expect(await page.locator('.orbit-outer').evaluate(e => getComputedStyle(e).animationName)).toBe('none');
  await page.locator('#restore-shortcut').click();
  expect(await page.locator('#detail-dialog').evaluate(e => getComputedStyle(e).animationName)).toBe('none');
  await page.locator('.dialog-heading .close-dialog').click();
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await expect(page.locator('#motion-toggle')).toBeEnabled();
  expect(await page.locator('.orbit-outer').evaluate(e => getComputedStyle(e).animationName)).toBe('orbit-spin');
});
test('favorites persist, empty search works, and unavailable GPU rollback is explicit', async ({ page }) => {
  await page.goto('/');
  await page.locator('[data-action="createrp"] .favorite').click();
  await page.reload(); await page.locator('[data-category="favorites"]').click();
  await expect(page.locator('.action-card')).toHaveCount(1);
  await page.locator('#search').fill('not-present-123'); await expect(page.locator('#empty')).toBeVisible();
  await page.locator('.nav-item[data-category="revert"]').click();
  await page.locator('[data-action="revertgpu"] .open-action').click();
  await expect(page.locator('#detail-description')).toContainText('غير متاح');
  await expect(page.locator('#execute')).toBeDisabled();
});
test('Windows bridge flow requires acknowledgement and distinguishes failure from success (mock bridge)', async ({ page }) => {
  await page.addInitScript(() => {
    window.calls = [];
    window.desktop = {
      info: async () => ({ windows: true, platform: 'Windows mock', cpu: 'Test CPU', ram: 16, dependencies: {} }),
      onLog: cb => { window.logCallback = cb; }, onDone: cb => { window.doneCallback = cb; },
      run: async id => { window.calls.push(id); return { started: true }; }, logs: async () => {}, external: async () => {}
    };
  });
  await page.goto('/');
  await page.locator('#restore-shortcut').click();
  await expect(page.locator('#execute')).toBeDisabled();
  await page.locator('#ack').check(); await page.locator('#execute').click();
  expect(await page.evaluate(() => window.calls)).toEqual(['createrp']);
  await page.evaluate(() => { window.logCallback('Access denied'); window.doneCallback({ code: 1, message: 'failed' }); });
  await expect(page.locator('#activity-summary')).toContainText('أخطاء');
  await expect(page.locator('#log')).toContainText('Access denied');
});
test('cancelled native confirmation never reports a completed operation (mock bridge)', async ({ page }) => {
  await page.addInitScript(() => { window.desktop = { info: async () => ({ windows: true, platform: 'Windows', cpu: 'mock', ram: 8 }), onLog: () => {}, onDone: () => {}, run: async () => ({ cancelled: true }) }; });
  await page.goto('/'); await page.locator('#restore-shortcut').click(); await page.locator('#ack').check(); await page.locator('#execute').click();
  await expect(page.locator('#activity-summary')).toContainText('أُلغي الطلب');
  await expect(page.locator('#detail-dialog')).toBeVisible();
});
test('layout stays within the viewport and resources remain explicit', async ({ page }) => {
  await page.setViewportSize({ width: 1060, height: 800 }); await page.goto('/');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator('#resources').click();
  await expect(page.locator('#info-body')).toContainText('PowerPlan_GUID.pow');
  await expect(page.locator('#info-body')).toContainText('autoruns.exe');
});
